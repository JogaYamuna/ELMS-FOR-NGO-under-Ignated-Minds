<?php
include('config.php');
if(isset($_POST['submit']))
{
    $email=$f_POST['email'];
    $sq=$_POST['sq'];
    $sqa=$_POST['sqa'];
    $pass=$_POST['pass'];
    $cpass=$_POST['cpass'];
    $query="SELECT sq,sqa FROM registeration1 WHERE email='$email'";
    $result=mysqli_query($con,$query);
    while($temp=$result->fetch_assoc())
    {
      $sq1=$temp["sq"];
      $sqa1=$temp["sqa"];
    }
    if($sq==$sq1 && $sqa==$sqa1)
    {
        if($pass==$cpass)
        {
            $query="UPDATE registeration1 set pass='$pass' WHERE email='$email' ";
            $result=mysqli_query($con,$query);
            echo '<script>alert("password reset successfully.......");</script>';
            header("Location:index.php");  
            exit();

        }
        else
        {
           echo '<script>alert("password did not matched.......");</script>';
           header("Location:main.php");  
           exit();
        }
      //mysqli_query($con,"update registeration1 set pass='$pass' where email='$email'"); 
    }
    //elseif ($pass==$row['pass']) 
    //{
      // echo "Data fetched successfully";
       //header("Location:index.php");  
        // code...
   // }
    else
    {
       echo "InCorrect data inseted! Try again....";
    }
}
?>

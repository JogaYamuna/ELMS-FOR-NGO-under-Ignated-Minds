<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 8px;
}

.about-section {
  padding: 50px;
  text-align: center;
  background-color: blueviolet;
  color: white;
}

.container {
  padding: 0 16px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}
</style>
</head>
<body>

<div class="about-section">
  <h1>About Us Page</h1>
  <p>Connect with us...</p>
  <p>Our mission is to provide you with the knowledge and skills you need.</p>
  <p>.</p>
</div>

<h2 style="text-align:center">Our Team</h2>
<div class="row">
  <div class="column">
    <div class="card">
      <img src="nammu.jpg" alt="Jane" width="300" height="250" style="padding-left: 100px;">
      <div class="container">
        <h2>Namratha Gudala</h2>
        <p class="title">Designer</p>
        <p>Never felt more confident about my self</p>
        <p>s170376@rguktsklm.ac.in</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="yammu1.jpg" alt="Mike" width="300" height="250" style="padding-left :100px">
      <div class="container">
        <h2>Joga Yamuna</h2>
        <p class="title">Programmer</p>
        <p>Keep up the Great work!I'm looking forward to learn more and more.</p>
        <p>s170357@rguktsklm.ac.in</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <img src="madhu.jpg" alt="John" width="300" height="250" style="padding-left :100px">
      <div class="container">
        <h2>Sagabala Madhu</h2>
        <p class="title">Designer</p>
        <p>Our Team rocks.Thank you for all your support</p>
        <p>s170830@rguktsklm.ac.in</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>
</div>

</body>
</html>

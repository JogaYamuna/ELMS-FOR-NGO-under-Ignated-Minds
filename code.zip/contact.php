<?php 
if($_SERVER['REQUEST_METHOD']=='POST')
{
  include("config.php");
  $firstname=$_POST['firstname'];
  $lastname=$_POST['lastname'];
  $country=$_POST['country'];
  $subject=$_POST['subject'];
 $query="INSERT INTO contactus (`firstname`,`lastname`,`country`,`subject`)values('$firstname','$lastname','$country','$subject')";
 $result=mysqli_query($con,$query);
 if($query)
 {
  echo "Data inserted successfully";
  header("Location:main.php");
 }
 else
 {
  echo "Insert correct Data";
 }
}
 ?>


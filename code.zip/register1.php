<!DOCTYPE html>
<html>
<head>
	<title> REGISTRATION PAGE </title>
	<meta charset="utf-8">
	<meta name="description" content=" registration page created by student of rgukt">
	<meta name="keywords" content =" registration,form,index">
	<meta name="author"  content="Joga.Yamuna">
	<meta name="viewport" content="width=device-width  inital-scale=1 shrink-to-fit=no">
	<link rel ="icon" type="img/png" href="yamu.jpg">
	<link rel="stylesheet" type="text/css" href="register1.css">
</head>
<body>
    <div class="mainbody">
    	 <header>
    	 	<hgroup>
    	 		<h1><big>REGISTRATION PAGE</big></h1>
    	 	</hgroup>
    	 </header>
    	 <form action="yamu.php" class="form-tags" method="POST" enctype="multipart/form-data" >
    	 <div class="row">
    	 	<div class="form-label">
    	 		<label>First-name:</label>
    	 	</div>
    	 	<div class="form-control">
    	 	   <input type="text" required name="fn">
    	    </div>
    	 </div>
    	 <div class="row">
    	 	<div class="form-label">
    	 		<label> Last-name:</label>
    	 	</div>
    	 	<div class="form-control">
    	 	   <input type="text" name="ln">
    	    </div>
    	 </div>
    	<div class="row">
    		<div class="form-label">
    			<label> Gender </label>
    		</div>
    		<div class=" form-control">
    			<fieldset>
    				<legend>Gender:</legend>
    				 Male <input type="radio" name="gender" value="male">
    				 Female <input type="radio" name="gender" value="female">
    			</fieldset>
    		</div>
    	</div>
    	<div class="row">
    	 	<div class="form-label">
    	 		<label> Date of birth:</label>
    	 	</div>
    	 	<div class="form-control">
    	 	   <input type="date" required name="dob">
    	    </div>
    	 </div>
    	 <div class="row">
    	 	<div class="form-label">
    	 		<label> Age:</label>
    	 	</div>
    	 	<div class="form-control">
    	 	   <input type="number" min="10" max="100" value="18" required name="age">
    	    </div>
    	 </div>
    	 <div class="row">
    	 	<div class="form-label">
    	 		<label>Email:</label>
    	 	</div>
    	 	<div class="form-control">
    	 	   <input type="email"  name="email">
    	    </div>
    	 </div>
    	 <div class="row">
    	 	<div class="form-label">
    	 		<label>Favourite-colour:</label>
    	 	</div>
    	 	<div class="form-control">
    	 	   <input type="color" name="color"><br>
    	    </div>
    	 </div>
    	 <div class="row">
    	 	<div class="form-label">
    	 		<label>Phone number:</label>
    	 	</div>
    	 	<div class="form-control">
    	 	<input type="tel" name="country code"  value="+91" size="2" maxlength="3">
            <input type="tel"  pattern="[0-9]{10}" name="phone"  size="10"  maxlength="10">
    	    </div>
    	 </div>
    	  <div class="row">
    	 	<div class="form-label">
    	 		<label> Address:</label>
    	 	</div>
    	 	<div class="form-control">
    	 	   <input type="text" name="address">
    	    </div>
    	 </div>
    	  <!--<div class="row">
    	 	<div class="form-label">
    	 		<label>Address:</label>
    	 	</div>
    	 	<div class="form-control">
    	 	  <textarea rows="5" cols="20" placeholder="enter your address"> </textarea>

    	 	   <input type="Address" name="address"><br>
    	    

    	    </div>
    	 </div>-->
    	  <div class="row">
    	 	<div class="form-label">
    	 		<label>Year:</label>
    	 	</div>
    	 	<div class="form-control">
    	 	   <select name="year" >
    	 	   	  <optgroup lable="RGUKT-srikakulam:">
    	 	   	        <option value="E1sklm">E1sklm</option>
    	 	   	       	<option value="E2sklm">E2sklm</option>
    	 	   	       	<option value="E3sklm">E3sklm</option>
    	 	   	       	<option value="E4sklm">E4sklm</option></optgroup>
    	 	   	       	<optgroup lable="RGUKT-ongole:">
    	 	   	        <option value="E1ogl">E1ogl</option>
    	 	   	       	<option value="E2ogl">E2ogl</option>
    	 	   	       	<option value="E3ogl">E3ogl</option>
    	 	   	       	<option value="E4ogl">E4ogl</option></optgroup>
    	 	   	       	<optgroup lable="RGUKT-Nuzvid:">
    	 	   	        <option value="E1Nzg">E1nzd</option>
    	 	   	       	<option value="E2Nzg">E2nzd</option>
    	 	   	       	<option value="E3Nzg">E3nzd</option>
    	 	   	       	<option value="E4Nzg">E4nzd</option></optgroup>
    	 	   	       	<optgroup lable="RGUKT-Rkvy:">
    	 	   	        <option value="E1Rkvy">E1rkvy</option>
    	 	   	       	<option value="E2Rkvy">E2rkvy</option>
    	 	   	       	<option value="E3Rkvy">E3rkvy</option>
    	 	   	       	<option value="E4Rkvy">E4rkvy</option></optgroup>
    	 	   	 
    	 	   	 </select>

    	   
    	    </div>
    	 </div>
    	  
    	 <div class="row">
    	 	<div class="form-label">
    	 		<label>User name:</label>
    	 	</div>
    	 	<div class="form-control">
    	 	   <input type="text" name="un">
    	    </div>
    	 </div>
    	 <div class="row">
    	 	<div class="form-label">
    	 		<label>Password:</label>
    	 	</div>
    	 	<div class="form-control">
    	 	   <input type="Password" name="pass">
    	    </div>
    	 </div>
    	  <div class="row">
    	 	<div class="form-label">
    	 		<label>Confirm-Password:</label>
    	 	</div>
    	 	<div class="form-control">
    	 	   <input type="Password" name="cpass">
    	    </div>
    	 </div>
    	  <div class="row">
    	 	<div class="form-label">
    	 		<label>Security questions:</label>
    	 	</div>
    	 	<div class="form-control">
    	 	    <select name="sq" >
    	 	   	  <optgroup label="choose Security questions:">
    	 	   	  	<option value="what is favourite food?">what is favourite food?</option>
    	 	   	  	<option value="what is favourite color?">what is favourite color?</option>
    	 	   	  	<option value="what is favourite God?">what is favourite God?</option>
    	 	   	     <option value="what is favourite movie?">what is favourite movie?</option>
    	 	   	     <option value=" what was your childhood nickname?"> what was your childhood nickname?</option>
    	 	   	     <option value="what is your dream job?"> what is your dream job?</option>
    	 	   	     <option value="what is your favourite in pasttime">what is your favourite in pasttime</option>
    	 	   	     <option value="what is your favourite place?">what is your favourite place?</option>
    	 	   	     <option value="what was the firest movie you saw in a theater?">what was the firest movie you saw in a theate </option>
    	 	   	  </optgroup>
    	 	   	 </select>
    	    </div>
    	 </div>
    	 <div class="row">
    	 	<div class="form-label">
    	 		<label>Security Q-ans:</label>
    	 	</div>
    	 	<div class="form-control">
    	 	   <input type="text" name="sqa">
    	    </div>
    	 </div>
    	  <div class="row">
    	 	<div class="form-label">
    	 		<label>upload image:</label>
    	 	</div>
    	 	<div class="form-control">
    	 	   <input type="file" name="ui">
    	    </div>
    	 </div>
    	   <div class="row">
    	 	<div class="form-control">
    	 	   
    	 	   <input type="submit" value="Submit" name="submit">
    	 	   <input type="Reset" value="Reset" name=" reset">
    	    </div>
    	 </div>
    	</form>
    	<div class="row">
    	<h2 style="text-align: center" id ="last"> <big><span style="font-size: 100% ;color:darkred;"> &hearts; &hearts; &hearts;</span>THANK U FILLING YOUR INFORMATION<span style="font-size: 100% ;color:darkred;"> &hearts; &hearts; &hearts;</span></big></h2>
        </div>
   </div>
   <div class="footer" style="width: 100%;">
   <h5><small> designed by Joga.Yamuna &copy; by 2020-21</small></h5>
   </div>

   </body>
   </html>     

<?php
include("config.php");
 $id=$_POST['id'];
 $dob=$_POST['dob'];

 $query="SELECT dob FROM students WHERE id='$id'";
 $result=mysqli_query($con,$query);
 while ($temp=$result->fetch_assoc())

 {
   $d=$temp['dob'];
 }
 if ($d==$dob)

  {
    header("Location:regis.php");
 }

 else
 {
    header("Location:elms.php");
    
    exit();
 }
 ?>


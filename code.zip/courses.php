<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Course</title>
	<link rel="stylesheet" href="style.css">
	<style>
body {

  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}
.main-head
{
	width: 100%;
	height:500px;
	background-image: url("https://png.pngtree.com/thumb_back/fh260/back_our/20190625/ourmid/pngtree-admissions-training-course-flyer-image_254831.jpg");
	background-repeat: no-repeat;
    background-size: cover;
    color: white;
}
.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 8px;
}

.about-section {
  padding: 50px;
  text-align: center;
  background-color: blueviolet;
  color: white;
}

.container {
  padding: 0 16px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}
body {
  background-color: #92a8d1;
}
</style>

</head>
<body>
   
	<div class="main-head">
	<h1><center>Courses</center></h1>
	<h1><center>Best Course's</center></h1>
	<p><h3><center>You can get the best Knowledge from our site.<br>We make you more comfortable with our services</center></h3></p> 
    </div>	
     <div class="column">
    <div class="card">
	<div id="python">
	<a href=""><img src="https://i.pinimg.com/736x/1c/86/84/1c8684b06bc7ad1e1f6b7b0099d87300.jpg" height="300px" width="300px" hspace="50" vspace="50" ></a>
	<div class="container">
        <p><button class="button">Python</button></p>
      </div>
    </div>
  </div>
</div>
<div class="column">
    <div class="card">
	<div id="python">
	<a href=""><img src="https://thumbs.dreamstime.com/b/java-logo-vector-design-commercial-brand-trademark-118452997.jpg" height="300px" width="300px" hspace="50" vspace="50" ></a>
	<div class="container">
        <p><button class="button">Java</button></p>
      </div>
    </div>
  </div>
</div>

<div class="column">
    <div class="card">
	<div id="python">
	<a href=""><img src="https://thumbs.dreamstime.com/b/dbms-line-art-concept-vector-database-management-systemt-round-banner-web-resources-programming-server-elements-77290437.jpg" height="300px" width="300px" hspace="50" vspace="50" ></a>
	<div class="container">
        <p><button class="button">DBMS</button></p>
      </div>
    </div>
  </div>
</div>
<div class="column">
    <div class="card">
	<div id="python">
	<a href=""><img src="https://w7.pngwing.com/pngs/580/809/png-transparent-data-structure-logo-brand-data-structure-blue-text-logo.png" height="300px" width="300px" hspace="50" vspace="50" ></a>
	<div class="container">
        <p><button class="button">Data Structures</button></p>
      </div>
    </div>
  </div>
</div>
<div class="column">
    <div class="card">
	<div id="python">
	<a href=""><img src="https://e7.pngegg.com/pngimages/46/626/png-clipart-c-logo-the-c-programming-language-computer-icons-computer-programming-source-code-programming-miscellaneous-template.png" height="300px" width="300px" hspace="50" vspace="50" ></a>
	<div class="container">
        <p><button class="button">C/C++</button></p>
      </div>
    </div>
  </div>
</div>
<div class="column">
    <div class="card">
	<div id="python">
	<a href=""><img src="https://www.kindpng.com/picc/m/42-423529_the-one-web-technology-web-technology-logo-hd.png" height="300px" width="300px" hspace="50" vspace="50" ></a>
	<div class="container">
        <p><button class="button">Web Development</button></p>
      </div>
    </div>
  </div>
</div>
	<a href="">Visit Us To Know More</a>
</body>
</html>

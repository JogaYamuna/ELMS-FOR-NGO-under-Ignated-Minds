<?php
include('config.php');
session_start();
if(isset($_POST['submit']))
{
    $email=$_POST['email'];
    $pass=$_POST['pass'];
    $_SESSION['email']=$email;
    $query="SELECT * FROM registeration1 WHERE email='$email'";
    $result=mysqli_query($con,$query);
    //$num=mysqli_fetch_array($result);
    $row=$result->fetch_assoc();
    if($pass==$row['pass'])
    {
      $_SESSION['email']=$email;
      echo "Data fetched successfully";
       header("Location:main.php");  
    }
    else
    {
       echo "InCorrect data inseted! Try again....";
    }
}
?>

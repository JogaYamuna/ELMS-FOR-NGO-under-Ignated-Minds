
<!DOCTYPE html>
<html lang="zxx">

<head>
<meta charset="utf-8">
<meta name="author" content="John Doe">
<meta name="description" content="">
<meta name="keywords" content="HTML,CSS,XML,JavaScript">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>E-learning management system for NGO | Govt. of India</title>
<script type="text/javascript" src="https://www.istm.gov.in/files/lms/js/jquery-3.2.1.min.js"></script>
<script src="https://www.istm.gov.in/files/lms/js/4n2NXumNjtg5LPp6VXLlDicTUfA.js"></script><link rel="apple-touch-icon" href="https://www.istm.gov.in/files/lms/images/apple-touch-icon.html">
<link rel="shortcut icon" type="https://www.istm.gov.in//files/lms/image/ico" href="https://www.istm.gov.in//files/lms/images/favicon.html" />

<link rel="stylesheet" href="https://www.istm.gov.in/files/lms/css/bootstrap.min.css">

<link href="https://www.istm.gov.in/files/lms/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

<link href="https://www.istm.gov.in/files/lms/css/matrialize.css" rel="stylesheet">

<link href="https://www.istm.gov.in/files/lms/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

<link rel="stylesheet" href="https://www.istm.gov.in/files/lms/css/style.css">
<link rel="stylesheet" href="https://www.istm.gov.in/files/lms/css/style1.css">
<script>
function check_asops_assessment_logout_time()
{ 
  var url = "https://www.istm.gov.in/lms/update_asops_assessment_logout_time"; 
  // alert(url);
  $.ajax({
			 type: "POST",
			 url: url,
			 data: {'shFCx34Ex297z':'315902e86dfd8b5f26809741df047bb1'},
       success: function(data){         
			 if(data)
			 {
				 alert(data);
				 window.location.replace("https://www.istm.gov.in/lms/home");
			 }   
     });  
}

var interval = setInterval(function () { check_asops_assessment_logout_time(); }, 5000);
</script> 
<meta http-equiv="refresh" content="1000000000000000000000000000000">
</head>
<body>

<header class="header">

<!--<div class="top_bar background-color-orange">
<div class="top_bar_container">
<div class="container">
<div class="row">
<div class="col">
<div class="top_bar_content d-flex flex-row align-items-center justify-content-start">
<ul class="top_bar_contact_list">
<li>
<i class="" aria-hidden="true"></i>
<div><img src="https://www.istm.gov.in/files/manpower_portal/images/logo-ISTM.jpg" height="45"  alt="India Flag"></div>
<div class="contact-no" style="color:#2a80b9;">
भारत सरकार<br />GOVERNMENT OF INDIA</div>
</li>


<div class="email"></div>
</li>
</ul>
<div class=" ml-auto ">
<div class="search_button search"><i class="large material-icons search-icone">search</i></div>
<div class="hamburger menu_mm  search_button transparent search display"><i class="large material-icons font-color-white  search-icone  menu_mm ">menu</i></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div> -->

<div class="header_container background-color-orange-light" style="margin-top:-10px;">
<div class="container">
<div class="row">
<div class="col">
<div class="header_content d-flex flex-row align-items-center justify-content-start">
<div class="logo_container">
<a href="https://www.istm.gov.in/lms">
<img src="https://img.freepik.com/premium-vector/flat-web-template-with-lms-concept-design-concept-learning-management-system_100456-8728.jpg?w=2000" width="145" height="110"class="logo-text" alt="">
</a>
</div>
<span style="color:#FFF; margin-left:10px; text-align:center !important;">
<p style="font-size:12px; font-weight:bold; line-height:1.2">GOVERNMENT OF INDIA</p>
<p style="font-size:18px; font-weight:bold;line-height:1.2">E-Learning Management System</p>
<p style="font-size:16px; font-weight:bold; line-height:1.2">Non-governmental organizations</p>
<p style="font-size:16px; font-weight:bold; line-height:1.2">Leraning platform</p>
</span>
<nav class="main_nav_contaner ml-auto">
<ul class="main_nav">
<li><a href="https:hujh">Home</a></li>
<li><a href="https://www.ist" target="_blank">About Us</a></li>
<!--<li><a href="#">FAQ</a></li>-->
<li><a href="https://tyu" target="_blank">Contact Us</a></li>
<li><a href="elearning.html">Applicant Login</a></li>
</ul>

<div class="hamburger menu_mm menu-vertical">
<i class="large material-icons font-color-white menu_mm menu-vertical">menu</i>
</div>
</nav>
</div>
</div>
</div>
</div>
</div>

<div class="menu d-flex flex-column align-items-end justify-content-start text-right menu_mm trans_400">
<div class="menu_close_container">
<div class="menu_close">
<div></div>
<div></div>
</div>
</div>
<div class="search">
<form action="#" class="header_search_form menu_mm">
<input type="search" class="search_input menu_mm" placeholder="Search" required>
<button class="header_search_button d-flex flex-column align-items-center justify-content-center menu_mm">
<i class="fa fa-search menu_mm" aria-hidden="true"></i>
</button>
</form>
</div>
<nav class="menu_nav">

</nav>
</div>
</header>

<section id="intro">

<div class="carousel-item active">
<div class="carousel-background" style="margin-top:150px;"><img src="https://www.business2community.com/wp-content/uploads/2020/12/learning-management-system.jpg" width="1000" height="1100" alt="">
</div>
<div class="carousel-container">
<div class="carousel-content">
<p class="font-color-white">E -LEARNING MANAGEMENT SYSTEM FOR NGO</p>
</div>
</div>
</div>
</section> -->


<style type="text/css">
	.ui-datepicker td span, .ui-datepicker td a {
    text-align: center !important;
    }
</style>
<link href="https://www.istm.gov.in/files/js/datepicker/themes/blitzer/jquery-ui.css" rel="stylesheet">
<script src="https://www.istm.gov.in/files/js/datepicker/jquery-ui.js"></script>
 
<section id="post_job" style="margin:70px 0 0 0;margin-top: 70px;">
<div class="container">
<div class="vertical-space-0"></div>

<div class="job-post-box">
	<div class="row heading"  >
       Login with Student ID Number    </div>
    <!-- <form> -->
<form action="https://www.istm.gov.in/lms/login/" name="login_frm" id="login_frm" method="post" accept-charset="utf-8">
                            <input type="hidden" name="shFCx34Ex297z" value="315902e86dfd8b5f26809741df047bb1" />
 <div class="row form-group">
	<div class="col-lg ">
		                    <h5 align="center">Login with Student ID Number</h5>
	</div>
	
	
</div> 

<div class="row form-group">
	<div  class="col-lg-4">
		<label for="exampleInputJobtitle" style="float: right;">Student ID Number<span class="star">&nbsp;*</span></label>
	</div>
	<div class="col-lg-4">
		<input type="text" class="form-control" name="application_no" id="application_no" value="" autocomplete="off" style="float: left;" />
                  	</div>
	
</div>

<div class="row form-group">
	<div  class="col-lg-4">
	<label for="exampleInputJobtitle" style="float: right;">Date of Birth<span class="star">&nbsp;*</span></label>
	</div>
	<div class="col-lg-4">
	<input type="text" name="dob" readonly="readonly" class="form-control" id="dob" value="" autocomplete="off" />
                	</div>
	
</div>

<div class="row form-group">
	<div  class="col-lg-4">
		<label for="exampleInputJobtitle" style="float: right;">Enter Image Characters<span class="star">&nbsp;*</span></label>
	</div>
	<div class="col-lg-4">
		<input class="form-control" placeholder="Enter Image"  type="text" id="word" name="word" value="" autocomplete="off" />
				<br /> 	</div>
	<div class="col-lg-4">
		<span id="captchaImg" ><img  src="https://www.istm.gov.in//files/captcha/1658082568.8061.jpg" style="width: 140px; height: 38px; border: 0;" alt=" " /></span>
		<a class="reloadCaptcha"  href="javascript:void(0);" ><img src="https://www.istm.gov.in/files/images/reload.jpg" alt="Reload Captcha Here"/></a>
	</div>
</div>

<div class="row" style="background-color: #f1f1f1; height: 60px;" >
	<div class="col-lg-6">
		<input style="float: right; margin-top: 10px;" type="submit" value="Submit" name="submit_contact_form" id="submit_contact_form" class="btn btn-primary">
	</div>

</div>
</form>
<div class="row" style="height: 60px; background-color: white;" >
	<span class="login_div_gap">OR</span>	

</div>
<form action="https://www.istm.gov.in/lms/login" name="login_mb_frm" id="login_mb_frm" method="post" accept-charset="utf-8">
<input type="hidden" name="shFCx34Ex297z" value="315902e86dfd8b5f26809741df047bb1" />                                                           
<div class="row heading"  >
       Login with Mobile OTP    </div>
    <!-- <br> -->
    <div class="row form-group">
	<div class="col-lg ">
		                    <h5 align="center">Login with Mobile Number</h5>
	</div>
	
	
</div> 
    
<div class="row form-group">
	<div  class="col-lg-4">
		<label for="exampleInputJobtitle" style="float: right;">Mobile Number<span class="star">&nbsp;*</span></label>
	</div>
	<div class="col-lg-4">
		<div class="row">
			<div class="col-lg-3">
				<span style="float: right;">+91</span>
			</div>
			<div class="col-lg-9">
				<input type="text" name="residence_phone" id="residence_phone" autocomplete="off" class="form-control" value="" />
             <br />     			</div>
		</div>
		
	</div>
	<div class="col-lg-3">
		<button id="otp_val" class="button btn-primary"  onclick="send_phone_otp();$('#otp_val').val('Re-generate One Time Password (OTP)');" title="Generate one time password (OTP)">Generate one time password (OTP)</button> 
	</div>
	
</div>


<div class="row form-group">
	<div  class="col-lg-4">
		<label for="exampleInputJobtitle" style="float: right;">One Time Password<span class="star">&nbsp;*</span></label>
	</div>
	<div class="col-lg-4">
		<input type="text" class="form-control" name="otp" id="otp" autocomplete="off" value=""  />
                  	</div>
	
</div>


<div class="row form-group">
	<div  class="col-lg-4">
		<label for="exampleInputJobtitle" style="float: right;">Enter Image<span class="star">&nbsp;*</span></label>
	</div>
	<div class="col-lg-4">
        <input class="form-control" placeholder="Enter Image Characters"   type="text" id="word_otp_tmp" name="word_otp_tmp" value="" autocomplete="off" />
		 <br /> 	</div>
	<div class="col-lg-4">
		<span id="captchaImg1" ><img  src="https://www.istm.gov.in//files/captcha/1658083255.9259.jpg" style="width: 140px; height: 38px; border: 0;" alt=" " /></span>
		<a class="reloadCaptcha1"  href="javascript:void(0);" ><img src="https://www.istm.gov.in/files/images/reload.jpg" alt="Reload Captcha Here"/></a>
	</div>
</div>



<div class="row" style="background-color: #f1f1f1; height: 60px;" >
	<div class="col-lg-5" style="margin-top: 10px;">
		
	</div>
	<div class="col-lg-6" style="float: center;margin-top: 10px;">
		<input type="submit" value="Submit" name="submit_contact_form" id="submit_contact_form1" class="btn btn-primary">
	</div>
	

</div>
</form></div>
</div>
</section>

<script>
  $(document).ready(function(){
  $('input[type = text]').attr('autocomplete','off');
  $('textarea').attr('autocomplete','off');
  $('.reloadCaptcha').on('click', function(){ //alert("hhh");
          $.get('https://www.istm.gov.in/lms/reload_captcha', function(data){
           // alert(data);
              $('#captchaImg').html(data);
          });
      });
  $('.reloadCaptcha1').on('click', function(){ //alert("hhh");
          $.get('https://www.istm.gov.in/lms/reload_captcha', function(data){
           // alert(data);
              $('#captchaImg1').html(data);
          });
      });
});


  $(function () {
    var start = new Date();
    start.setFullYear(start.getFullYear() - 70);
    var end = new Date();
    end.setFullYear(end.getFullYear() - 20);

    $('#dob').datepicker({
    dateFormat: 'dd-mm-yy',
        changeMonth: true,
        changeYear: true,
        minDate: start,
        maxDate: end,
        yearRange: start.getFullYear() + ':' + end.getFullYear()
    });
});
</script><footer id="footer" class="background-color-red">
<div class="container-fluid background-color-orange main-footer">
<div class="container text-center">
<div style="padding-top:15px;"><p>© 2022 ---E-learning management system for NGO | Govt. of India</p></div>
</div>
</div>
</footer>


<script data-cfasync="false" src="https://www.istm.gov.in/files/manpower_portal/js/email-decode.min.js">
</script><script src="https://www.istm.gov.in/files/manpower_portal/js/jquery.min.js"></script>
<script src="https://www.istm.gov.in/files/manpower_portal/js/bootstrap.min.js"></script>
<script src="https://www.istm.gov.in/files/manpower_portal/owlcarousel/owl.carousel.min.js"></script>
<script src="https://www.istm.gov.in/files/manpower_portal/js/jquery-ui.min.js"></script>

<script src="https://www.istm.gov.in/files/manpower_portal/js/custom.js"></script>
<script>
	history.pushState(null, document.title, location.href);
window.addEventListener('popstate', function (event)
{
  history.pushState(null, document.title, location.href);
});
</script>
</body>

</html>
<?php
$host="localhost";
$user="root";
$pass="";
$db="elms";
$con=mysqli_connect($host,$user,$pass,$db);
if($con)
{
	echo " ";
}
else
{
	echo "failed to connect";
}
?>
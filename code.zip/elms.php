<!DOCTYPE html>
<title>E-learning management system for NGO | Govt. of India</title>
<link rel="stylesheet" href="https://www.istm.gov.in/files/lms/css/bootstrap.min.css">
<link rel="stylesheet" href="https://www.istm.gov.in/files/lms/css/style.css">
<link rel="stylesheet" href="https://www.istm.gov.in/files/lms/css/style1.css">
<meta http-equiv="refresh" content="100">
</head>
<body>
<header class="header">
<div class="header_container background-color-orange-light" style="margin-top:-10px;">
<div class="container">
<div class="row">
<div class="col">
<div class="header_content d-flex flex-row align-items-center justify-content-start">
<div class="logo_container">
<a href="https://www.istm.gov.in/lms">
<img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhUTExMWFRUXFRUVFhUYFxUXFhUVFRUXFxUVFRUYHSggGBolGxUVITEhJSkrLi4uFx8zODMtNyg5LisBCgoKDg0OGxAQGy0lICUtLS0tLS0tLS0rLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIANoA5wMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAABQQGAgMHAQj/xABEEAABAwIEAwUFBQYEBAcAAAABAAIDBBEFEiExBkFREyJhcYEHMkKRoRQzUrHBI2JygpLRFSRDsjRTouFUY3ODw/Dx/8QAGwEAAgMBAQEAAAAAAAAAAAAAAwQAAgUBBgf/xAA8EQABAwIDBgIIBAUEAwAAAAABAAIDBBESITEFE0FRYXGBkSIyUqGxwdHwQmJy4RQVM5KiI4LS8Qaywv/aAAwDAQACEQMRAD8A7ihCFFEIQhRRCEIUUQhCqmK8aRMd2UDHVM34YtWj+J4v9L+NlVz2tF3FFhgkmNoxfnyHUnQDqSArWkWL8VUlNftJm3BsWN77weha2+U+dlW5aCuqtauo7Bh/0IDY25h7ufkS4eSm4dgFNB93E3MPidZ7/wCo7elkIyuPqi3f6fVFcKSH+o8vPJmni85f2h3QrU/jWeX/AIShkeDtJIcjfpof6lqklxeXeWCnHNrWlzvm4O+hTuSa2pNh4ojkDhcG46qtnHVx+HwQjtNjcoomD9V3n/I2/wAQq+OHqo6y4lO7waXNHyDrfRYScEwu9+eod5vZ+rSrGXjqglVwNVTtirvcPA7NaPgFVz7PqP8AFLfrmZf/AGLYzguNv3dTUN/mH6AKTxDjQihc6J7S9ttL3+ix4RxWSpiL5LXDrC3SyvuW2vZD/nlYXYd4T5ELUcArGG8WJS/wvLnD6uI+i2irxiAbwVVuoyut6ZP1U3GcWZTMzvBIuBputGEcSQ1DsrCc1r2IsuCPK4v5n5on86eThlax3dgHvbhPvXkfHxi0rKSaHYZm99p8bkDTyJVlwriClqfuZ2PP4b5X/wBDrO9bKCKhrrtuDyI0PzCT4jwpSS65Ozfvmj7lj1sNCfRdxSDQ375e8fRHbU0M3rNdGebTib5HP/LwV8Quex/4lRe48VkI+B9+1A/dJNzoOp/hTvAOM6epOR14ZtjFL3TfTRpOjvLQ+Cu2UE2OR6/LgrSUTw0yRkPaNS3O3cZEeVuqs6EIRUmhCEKKIQhCiiEIQoohCEKKIQhCiiEox3HYaRmeZ1r3ytGr3kfhb8tdhpcpdxNxOKciCFplqn2DIxqGl2zpLbDnbTbkNUqwvAiH/aKp3bVJtqdWR88rG7adfkBzC+XPC3X3D6poRMjYJagkA+q0es7t7Lebj4AlapmVeIazk01MdoWk9rK3/wAwnYa7Ecvd5pxh9BFAzLExrW8yN3eLnbuPmpBckcfETHTPia1xyNJcfEcgqNZnfU80hV7QdI0MNms4NHq9zxJ6m5T26rPGUkzWNMcojbchxP0SSt4lmqz2MDSx1zfXWw/JR8Gq3zsmpJiS6xLL7hzeSM1hbmVlySYgQFIx/Fc9FG0EvJNi8X3bvdZ8IYtMI3AtvFGx2vPNuLqLwcc7J6Vw1IJaDyI0Nvoo3Ddc6B8kDo3ODzkOh01tdELciELMZ3UU4i+cvfJO5p+Fov8ALRTaLGJvskzHF2gGVxvexNiLqQ3AKumkd2LGyNdsSAbD12Kb4HwnLkk7e95G2tqcvO6hc2ygY4n0QqrFhANG6oznNmtbla6uHs9b/lvN5SxnAdTZzDJ3NwNbE8rhWfhvCH00IjfqQSbgaaqshBbrxRo2OxZg+Sr/ALSprMjZ1cT8v/1Vrh2s+zyvefhjNvEnZWjjPCJp5Yyxt2N0OvU6quVWDPNS4FpDBqXW0ytGuvorMIw2QpXekbpbHPK6W4c4Pe6+hPxFXTE8TqGSMZC5ry0ND2k6knwVe4ZjDp3zO9yIOf4abBbMA780tXJ7rLu/mOwXXfBVN+GS6ZA92UE72181DxbBYKptpWC/J40e3yd+h0VFwniydud7mmRl/Rtz1V2wDGWVUedoIINiDyKA+MgZ6J+mqnxvDoyWuHEH5qBDiNXhukt6qkHx69rE3xudgOumm7dldcKxWGpYJIXh7T03B/C4btPgUtDlXqzBJYJDU0BDH/6kJ+6lA3AZyO/TwsdxhzmaZjlx8OfZbjKiGsyksyT2tGu/UB6p/MMuY4roSEi4a4ijrGGwLJGaSRO95rhobdRfn87FPUdrg4XCWlifE8seLEcEIQhWVEIQhRRCEIUUQqtxZxGYMsEAz1Ulg1u4jB/1HeVja/Qk6BTeKMdbSRZ7ZpHHJFHYkvedjYa5Rpe3gNyEi4dwp0WaaY56mXvSOOpbfXs28hbTbTQDYBAkeb4G68en7lNRhkMe/lFxo1vtHr+Vv4uZ9EcbZ4FgrYAXOd2k79ZJT3iS7VzWuOuW/wA/oMKviGGOVsRd3jp4DzTkqi8acNnWeIa7vH6hdja31VjVU0sjjI43J1P3oBpYZAWU/jPHnwhscZs5/wAXQKsYdniq2iOXtM1i9w2sfeDlKw2qZWQmGUXmY09mb2LtNkow+CVxdDcRWuZHHQ28SmGiwskHuJN01x6nNLVtni1a519NdfibomsnD8j6plRDZrTZ5vvfmLKN7PqRz53sHfib8RFxfkRfmuqU1I1o21VTcGyYgpzILnRVfDOD2MmM+oc4k+AvvYKwxYTEDmygnrYJgAiy5bmn2U8bRkFrbEBsAtlkLEuXUdZ2WJaFrdO0buAWQeuXCixfA07gKHPhjSNPrqExuvFLAqpaDqqjiHDLMj2BuQP94t0vZVXGOHZYqUQwDOC7M88yOQXWC1QqmhB1GhXMwlJKNurVyTG3ClpWUrfvH96TrryWsV76KJsMf3z7Oeel9mjxV/xDBonva6RgzNNwfJUrHcPmhrDUCPtGXzDoLDmrNcDkfspF8ZZqsWcVVELHsnb3y3uE6EX6p9wNX1EkZdLq34XHc/8AZVWmjfiFQZJNGN36ADZo8VPg4wkY4tZEOxZpYbho0uo5txYDPiuNdZ1zw+/JWrG8EL3CppT2VSw3BGglA+B/IkjS58jps64W4gbVsII7OZhyyxHQtcCRcA65SQfLZQsLxBszGyMNwfp4JbxBQSMe2tpdJ2D9owbTRj3g5o942HnppqAls2HEPEfPv8V6SkqW1LG08pz/AAOPD8pPsnh7J6XV+QleAYwyrhbNGdDoWndjhux3iPqLHmmiYBBFwgvY5ji1wsRkQhCELqqhaKidsbXPeQ1rQXOcdg0C5J9FvVI46q3TPiw+M2MmWSdw+CIHbbnYn+UD4lV7sIujU8IlkDSbDUnkBmT5eeih4Tmrah1dICGNJZTRke6Gm3aFv4ib+t+gVjWuCFrGtYwWa0BrQNgALALYl2iw68UpVVP8RKXgWGjRyaNB8zzcSUFYFl91mgqyWIVSl4Pb9pErHFrb5i0b5vDwU6fgSOebtXPc1p95v4vVWSkp858Am7W2CK0nVSOmacyouGYbHAwMjaGgdP1U0LC68Dle6cAAFgtl0XWF0XXLqy9JSTH8SMYyt94/QJyVUuKGkS38FmbWnfDTFzMjcC/dM0jGvlAclckziblxJTDCsWcxwDjdp68kqusoxcgeIXjYZ5Inh7Tn8VsyRtcMJC6Gx1xdZtUelHcb5Bb7r6I03AJXnNFndeLHMvA9duurCogDhYpNVU1rtcLg/IhPwtNRBmFiuObdDkjDguc8U4QY6f8Ay7cuV+chu5VMbIHTN7IO79mvb4nRy7BJHYkFRIcMia/O2NocedhdcbJbIrMfT55KJw7hX2aPIDe5LvK/JN2myxsvUMm5ujNaGiyrhl/w6rEo/wCEqHZZB8MMpNw/wG/pm6BdEVVxKhZPE6J2zhvzB3a4eINj6LXwDiTnROppvvqd3ZnfvRjRjtd9iPIA81yM4XYeB0+YW4X/AMTBvT67LB3VujXeHqk/p5q3IQhMJRaKiZsbHPebNa0ucTya0XJPoFQ+FGGZ01Y8d+d7st92wtNgPoB/IE39olU5tMIY/fqJGQtHOxN3W8NA3+ZbqOnbHGxg2Y1rB/KLJeQ3eBy+J/ZGkduqTLWQ2/2tsT/c63fCQtq9Xi9Ciy0IY25A6rwqbhkWpcfRdaLldY3EbKdBDlFgtq8uo9RXxM997W+ZARx0TmQW4tSjFpJY++zVvMJpDUseLtcCOoN168A+SBPDvWFocQeYV2ODTe11W4uJTfvN08FMh4ijO4I80rx3C+zOdvunfwScLysu0q6lk3chueo1Wq2mp5m4mhXmHFInbOC04jSsnbYEXGxVMWxkzm7Ej1RP57vGlk0YIPVV/gMJxMdYphLgUoNgL+KnYfhTYiHSuF+QSGfFZWiweUukqHu95xPmUtHLRxu3jIyTwBOQ+qMWTOGFzgO2qvlRj8DPiuRyCV1HFw+BnzVSXgR5NsVL9LDsPqqMoYhrmn/+N1EzsrNL8hy9Va8MpSxgzOLjzJ6pbwxhYjYHmxc7XyCfgLa2fTyBu9mcS48+ASFTI0nCwWA962NXpWIcvcy1EsoWIU9xmG4SwJ/e6S1UeV1vUKjxxS8zeKxXi9XhQ0FeKu4u/wCy1sFYNGPtBP0s7Z58rA/+2rGl+PUH2imkitclhLf426sH0A9VVwNstU7s+dsU4x+qfRd+l2R8tR1AVwQkHBWJfaKOJ97uA7N3XNH3dfEgB38yEy0hwB5ok0bopHRuGYJB7jJJcePbYpCy9208JlI/febD/wCIpyFX8HJkr6+U/wDMbCPKO7T/ALGqwJVpvc8yfoptLKVsfssaPMYz73FeBZLxBV1nITinjytASmmbd4CclXYEeEalI+MMZ+yUz5dyBYeZXz3iWLzTvL5HuJPjoPJd19pGFuqKN4YLuHeA62Xz69hGh0I3C0qUCxI1QagnErLwdxVNSzt75MZIDmk3FvBfQMU4cwP5EA+i+aMBw19RMyNgvdwv4C+66N7Q+MTTxNo4HXflDXuHIW5Ks8Yc4ALsT8LTdL/aXx258nYU7rNae84cyOS38LY19pj195ujv7rlBcSdd11D2RUgkjnbz0IKzNs7NZUU12j0m6deYTVDVuZNnoVYwvV7IwtJB3Gi8Xzoi2S9QDdRKvktJC31fJaSjt0VViitpnCAy7C4Hndb6GmMjwwcyn3GdMI6NrRpZzVtbHo99LvHeq33lBfMGyNZxJ9yX8GcSZSIZTps0n8lf2uXCmkj9F0LgziTOOxkPeHuk817B7OIS1fR2/1GDurXiFayFhe82AVQn49Ad3WEjxXntIncBG0e6bkqhrrGAi5Uo6KN8eN+d117A8fjqR3TZw3ad1LxKO4v0XMODpCKqMA7nXxXWJ23aQhSNASVdTiJ2FuhF0oXqxWSXWSvEB1kFYqKFLuDXdlV11JsGyCdg/dl1PoB2YQvZz2eMQkaCelcw+LmFzz9GNQiQkAEHgT9VsV7vSZJn6TGnLmBhPvaVA4RlvHPKfjqZnX8LMP5kqZJjcINs3yCquBSkYa225kkv9E1w3BWyMD3P3+ixJaubebqEC9r5/ubIW0I2CqlLzkHEZdFYaSsZILtN1IVQw8dlU5WuuL281b01RVLp2nEMwVnyMwHLQqThw7/AKJq5K8MPePkpGIYjHC3NI8NHiVpM0RosmqS4X0Kp/EXCWHuJllDWHcm9ki4j9qbG3bTNzH8R2XMcYx+epcXSyON+V+78k3FA/U5IckrdNVdcS4po6Jro6CO7yCO06eS5pUzukcXvN3E3JK2rRKxNNjDUs5xctZXVPYbJ+0nH7oXLFe/Y/WFlcGX0e039NlWUXYVaI2eF1TiWis4SDY7pEAr1iFOHsLfDRUeRmUkHkvne2qXdT4xo748V6mhlxswnUKHV8loupFXyWqCIucGjckBZzASAAmyrTwdQWBlI30C1e0ScCEM5kg/JWagpxHG1o5BUj2kzDNG3nrde9oKcQRtYPHusmB2+qg5UpZMeWkOabEagrFa5ZLBaNlvFXWCvZXw9lI4Nlb7pPxJPLwrUg2yX6G6qnaG9wbHlZWHBeMqiCwLs7eh/uq2I0SRZJFfdWtyPyVz4Q4XdC7tJfe5DorkqtgvG1PPYOOR3Q/3VnjlDhcG4QXXvmsaodI595Bmk7xqfNeomPed5rG6WKyzksHOsoZxWIC+bQGy9xm/ZOt0VObZ2Vuthqf1WRtCvkgdhYBpfNFiiDwSSrJx5UdnUUE42AqBf+KNtv1Xihe142pqYjcPNvIsCFpPmLHnrb4Be1oKIVNLG4nQEf5OPzWHDVCH0ssOxZPKwegYo0lBMzu3sPPRM8Ge5tRXx821Dnjyfcj6ZErDHSvcHPy26n8libSYy7bD0jftkbea83WFwqpbkWNnaX9YB3wKZYDQNz5i4Fw5DWysireEdlFIAHlzjp4KyBO7Lw7oga3zWZKSXXP0WiYTlrhAWhxG5XMeIuFcUlJdLeQdAf0XWqM2eE4yBbkMpYMgrMYHNzXy5WYVNF95E9vmColl9T1NFHILPY1w8RdVTGfZ3STg2b2bt7tTbaocQqGnPBcFCxcFeeIPZrUQXdF+1b4b/JUqogcw5XNLSNwdEw1zXDJBLSNVCc1NOFq3saqF97APFz4X1UFzbrTex8lCFwc19ZQvDmhw2IB+aqXENPllvydqpvAGK/aKON17uAs7wIUjiiG8Yd0K8vtmn3lM7m3P6+5bdFJhkHVU2r5JjwrS55s1tG6+qXVfJWng2CzC/mT+S85sqLeztHLPyWpVvwxHyVkC5XxzVCSpNtmgD1XTK6cMjc46AAlcYxCozyOeeZJXu4xdK7MZd5fyCjudbVQJ35is6mW+i0IpWwSswsCnGE8OVFQe4wgfiOgV1wr2dsbYzOLj0Gy45wCVlqY49SuaMYSdAT5K3cOTYjGRka8t6OvYrpOH4DTxCzImj0U+Rga06bBDMl0hLXhwthuOqrNFNK65lZld4FTAvLLKyTWATc3S3G6/smaC5OgVckqwNMgufet+Sc8RRB1rOAcORKSfZXgWAzOfzGtgvLbUe507mnhomYgzDnr5fTRNfaND2hoYre92p/ojb/f6LxT8RjMmKUTDtFTSSO/na6M/UNQvTYMbifvQLeNY+nhiYw/hufFzvlZaMQYIcXd0qacO8C+Owt/TH/1KDi2H/tHEuDWnrum/tFhyNgrGgl1PM0ut/wAt5GYepDR/MVjimHCfKQdNCD1B2SO0acyMIaLkG4Hf7Kzas/0pgdW4Sdc2Zf8AqWKvMlijILbvcDvsFcKWXM0O6hJ5eHmZLA97qmWGUnZMy5syX2fBPDKQ5uRGfySErmOzBN+qmDQg9E7jdcApImGGS3Fui3GHNchNjZTyFiWrNCKmVrLFXuIuEKerBzsAdycN1ZFiQoCQbgrhAOq+e+LOBp6MlwBfHycOXmqfKxfV00IcMrgCDyK5Xx17Ofemph1Lo/7JuKovk5KSQ2zal/sWxzJI+mcdHd5o8ea67iceaJwtyK+Y6GofTTtkF2uY65HkdQV9KYJiTamnZK03Dm/W2qDWRXB6ghEppLZclRasageiveAQ5YWaWNtVTK+IiXL+9+qvsbw2ME7Bv6LyewYrPeeWXv8A2W3tB12tA4qs8fYlki7MHV/5Ll1TNyTrizF+2mc7kDZq2cLcJSVRD3gtj5nmfJeub6Lc03CG00HpdykmFYVLUOyxtJ6nkF0jh/gSKKzpe+/6BWfDMLjgYGRtAH5qbZCc++izZ6178m5BYRQBosBYeC25V61eqlkmvAFExGSzbdVLKUV8t3eS47RDkdZqjrGRxAPksiUl4grywBrTZ258klUzCGMvPbxKWa0k2Cr87s7nFxObPYD1U7CszagNBuMvos4sJ7ZoeHAOO4U6no20kcszzctY4+dhoB4k2HqvO01HM97HWNsjfhz8+mqbLg8YG5k5AdTopPDn7bE62f4Y2sp29Li2cDydH/1IUv2fUbo6NrpDd8znTuPXP7p9Whp9Sheuivhvzz807XuG/LAcm2aM/ZAbfxIJ8U7xahE8MkR2ewtv0JGjh4g2PoqdwhVOdEYZNJad5hcPBpIYfKwI/kKvyoXE0f2OtZVDSGotFN0a/wCGQ69AP6XdUOYWs7wP30K5E3fxPp+PrN/U0af7m3tzcGphXVzYrZuZsEkfj0mc2Ayg/RTeIqUuaHAXLTskFOwvedLAjXwXndo1M7Ziy5AGYtl4/wDazoWMLS45/Y+IVzpKgSNDhzUmCXK4H5qtYXiLYy2Eajm7xViGy1qOpE0YN/SGvdCLSw/DsnzHX1WaVYfUW7p9EzBWkDdNMdiF1kvLL1C6rLErFzVmQiyii5l7ROAxMDPALSDVzRs7/uknslx8wSOo5Ta57t+R5hdmLFzf2gcGFzvtdMMsrDmLR8VufmjseHDA5AezCcbUwr4/820ci8Ldx1jXYxdk0952nkEiw/H2zZJnd1zBZ4P4xyUzBcEfWTGpnByX7rTzWNsyHdPmxe2VtXaQyV+gHmeCgcH8JGZwmmFmbhp+JdNp4g0ANFgNgsooQ0ADQDktoC03EkpKeZ0zru8EAIsvULiCheEr1a3vAF1FFqrJsrfFJittRNmdflyWslBebpR78RUDGZS2JxBsbJDBJHOAx9w+1g7r5qfxIS5oy6gHUBI+372a2UgWAHXqvMbQmvUHiAAOhRomXZca/BTYqGaKQBp0J3G3qFK4qBmfT0Lfeme10hFrtibe5+hI/gS+lL2PD3usAC9xJ2aNST6J5wJA6eSaveCO0JihB+GJpAJ35lrR5td1Teym4sVuJ55W1P0utGjaWONU4g4BkebzfD5Zu7DqrnBEGgNaLAAAAbAAWACFtQvRJNCX4zhrKmF8L9nC1+bTu1w8QQD6JghQi4sVZri1wc02IzHdc/4Zq3WdST6Twd0/vxC2Vw6ixHoWnmtXErS22UWbzt18U44ywV78tVT6VEOoG/axi92FvM6m3W5HMW04ZXx1kIe3Y6ObuWP5tP6HmLLLq6YysMXEZjrb7sfuxKuMEirjHok+kPZd/wAXat8W8M6+yoZE0ZO9IRv08k2wquLWgSnU7dfVLqimbA4knM65yj9SosUDpA6VzrW5+PQLz8cksL7jUcPjdKua14vw5nUnkruCmFFV30O/Iqn4DiJyuznQcynsbw4XBuOoXpKWrbM3EMjyQPSjcQVYgVklVNXW0d80yjdcJ8G6Za8O0WaEIXVZeFa5AthSbHq4xs03OyDUTNhjMj9ArMYXuDRxUGo4Wp3SZ7Ad7M5o2J8k/iYGgACwGwVDNS698xv5qz8PV5kaWu1LeayqHa0c8pjDcJOff903UUr2Rg3uAnoXqxasltpJCELRNOG7qKE2Wcj7JVV1ObQbfmsaipLvAKO51kJz0tJLfIIJSXiGuLWgMPvbkLLG69zW9yxB0JHJLMMo+2jcC7UHQLDrat0jjBCL348+OXPLXnoLqRsFsbtLrTPSSRNbIH3B53WyWgMjGysBJJ1C2RYNOe4TZl/RMcYxEUUTWRjPM6zImWzEuOgOXpcjz0CTp6LeElwLWga9fmmomvlkayKxcT7uvTnyGaQz00lRMyjae8+z6h4/04gQS3zNxp4tHNdRpKdsTGxsGVrGhrR0a0WASTg/APssZLzmnk78z9+8dcgPQXPmST4Cxr0dJTiGPCE3VysIEMR9BvH2idXeOg5NA4koQhCaSaEIQoohUTiPCX0krq2mF2u1qYOT23u6Vo67k+p2JV7QqPYHBGgmMTtLgixB0I5H5HgbEaLm8NA2qc2aN943b395p3LHDkQtVRgsoJDT3L330+SZ41w/LTPdVULbg6zUw9145mNo57mw16fhOh2KirgLqfcfeMOj2eFvnrsVg1Gz4mMcbG4zyzv2vw58QpPC5g3sJvHpnqzkHfJ2ju9wk8upEUeovr4lS6apkgkEZdcaaeawiwqVrRI2+a+3NYGlewGV+/K+9+qxwHxjEAQdQUAlhFrg/ElW4Tt2uL+a3wzluxVIjpHOjdKXEW28Uzw/Fy2HM/Ug2HituHanpf6rbC1wfv4oDoiM2m+dvFXOHEAfe0UtkgOxVRpcYjfYXsbbIpcWD5Cxt9OafbXwm1nA3NlBI4ahXEpPxBRGRnd3GqxZVvHNbft7ugRp42TRmN2hRY6kMcHDgqgYXXtlN/JWbhyiLAXO0vyWx2JNB1DbrGfFcu5a2+yyKPZsNLJvXSXt2Fu+abm2iJG4QE7WuSoa3cpK2sLxcOuPBYSPAFyfVbQlBGIaJAzcgmE+IX935qG919zdQKjE2NaXDvAaGyVV2MPLA5mgNweoSE+0YWcbnp9dFT05CrACCqzjVe8uMZ7ovupvDTX5S5xuDt5rZxBQZ25m+836hKVLpKmlxi45jmPvNdZhZJZ2aRTROhcATdrh6EKXRYdIJWmM2adb+HRRsLpu2eGvcdNh+ie4xjUdI1sbQXyusI4m6uJOjbgagX+fK6So6QTXeThaON+P3x4cE22KWWQRRi7jry78ALDUrfjWLx0keZ+rjo1g95zvL9V5wngD85rKvWocO4w7QMOwAOzrH0ueZK84Z4Zd2gq6yz6g6tZuyEcg0bZh9PE6q5L0zGEnE7wHzP3l30bc6OmjMMJuT67+f5W9OZ/F21EIQjpJCEIUUQhCFFEIQhRRCqnEHCgkf9opndhUC5zA2ZJ4SNA+tvMHla0KrmBwsUWGZ8LsTDbhzBHIg5EdCuf0XEWR/YVrPs8/Jx0ik5Zg7YfMjxvom9dSCRhadjsf1TnFMKiqWZJo2vb4jUHq1w1afEKoycOVlHrRydvF/wCHlOrRppG7QdenkUvJES0tf6QPn4/t5IjqenqM4zu38iTgPZ2Zb2dcfmChSYLN7gN23v8A/QolZFZzYm6238SU3ouK4XO7OcOp5R7zZAWi/g88vOya/Yo3EPAB5hw1v6rGl2SCLwu48UtMyop3DfNty5HqDofA26pJV4UyKIvub5beqjYBSPc4PBsAdfFPcZozKzK3dRMBppY7tcLDl5qklG1tU1oacJtmOPW6AJTujnmfgm007WC7iAF7FM13ukHyUXE6ETNyk2tqvMLoOxBbe9zdamOff4cIwc/s88kHK3VL+JaIkCRvLfySh87pzGw8lcahl2kHoVU8GFqgac3LI2hA1k4tkH6+ef17pmF/oHm3MKRWVT84gjOUC3zWmOpka50UhvfTy6KRitBI2XtGC/8AdY0lDLLKJHi2v5JaRkhlLM8V7eH34WvdcGDBwtbxuouHyACRjjYEH5hYUHea6PqLjzCeT8OB78wNgdwpn2KCAZ3FrQBq5xAA8ydkePZtQ42IAA4ru8x3DQSTbwIS/hlkjbhzSG8k8kc1rS55AaASSTYAdTfkkM/FQe7sqSJ9RL+6LRt8XO3A8dvFbqbhKepIkxCXu6EU8biGD+Nw357XP7y2aWLdR7tpxa9Bn8vNOjZxB3lUd2DnbVx7N+ZsOqUx1bp5XR4dGXuuc9Q4Wjj8QSNT/bQOVt4b4WjpSZXEy1DtXzP1Ou4Z0H1P0Dqjo44mBkbGsaNmtAAHXQc/FSk1DTMi0H0H3z1V5aoYN1CMLOPFzv1H5DLuc0IQhMJNCEIUUQhCFFEIQhRRCEIUUQhCFFEIQhRRQMTwyGoblmjY8cswBI8Wndp8QqvUcCmMl1FVSwG98jjni8gDqB4nMruhUdG12oTENXNCLMdkdQcwe4Nx7lz+R+K0/wB5Tx1LR8URId/QdSfJq1u4xiYbVEE0B/ejIHpz+i6ItMgu3XVV3R4O881d09O/+rCO7SWn/wCh7lToOJ6N+07R/Fdv+4BT4a+ndtURO8pIz+RTDEsDpS0uNNDfr2Ud/nZch4sp2Mc7Kxrd9gB+SVdMW6gLSg2JTVGbC5vcg/ILqZqIrfex2/jb/dQ5KukYb9tED/6jAfzXB4ZDnGp36rpHCFDE8jPGx38TWn8whb8O/CExP/4vDDYueT4W+qs1TxXRs3mB8ru/2gqI3i8SD/LU083S0Zy38SL2+SulPg1MzVtPC09RGwH5gKeE4wOeL3t4fusqaOjpn4N0XHq7LyDQfeqFHBis9/2cVK083Ozvt5AEehAUum4CjcQ+qmlqXA3s4lsY8mA3Hzt4K5oV9y38Wff6aKp2hK0WiAYPyix/uzd71FoqOOJuWNjWN/CxoaPOw5qUhCKkiSTcoQhCi4hCEKKIQhCiiEIQoov/2Q==" width="145" height="110"class="logo-text" alt="">

<!--<img src="https://img.freepik.com/premium-vector/flat-web-template-with-lms-concept-design-concept-learning-management-system_100456-8728.jpg?w=2000" width="145" height="110"class="logo-text" alt="">-->
</a>
</div>
<span style="color:#FFF; margin-left:10px; text-align:center !important;">
<p style="font-size:22px; font-weight:bold; line-height:1.3">Ignited Minds Organisation (NGO) </p>
<p style="font-size:22px; font-weight:bold;line-height:1.3">E-Learning Management System</p>
<p style="font-size:20px; font-weight:bold; line-height:1.3">Leraning platform</p>
</span>
<nav class="main_nav_contaner ml-auto">
<ul class="main_nav">
<li><a href="ing.php">Ignited minds</a></li>	
<li><a href="main.php">Home</a></li>
<li><a href="aboutus.php" target="_blank">About Us</a></li>
<li><a href="contactus.php" target="_blank">Contact Us</a></li>
<li><a href="elms.php">Applicant Login</a></li>
</ul>

<div class="hamburger menu_mm menu-vertical">
<i class="large material-icons font-color-white menu_mm menu-vertical">menu</i>
</div>
</nav>
</div>
</div>
</div>
</div>
</div>

<div class="menu d-flex flex-column align-items-end justify-content-start text-right menu_mm trans_400">
<div class="menu_close_container">
<div class="menu_close">
<div></div>
<div></div>
</div>
</div>
<div class="search">
<form action="home.php" class="header_search_form menu_mm" method="POST">
<input type="search" class="search_input menu_mm" placeholder="Search" required>
<button class="header_search_button d-flex flex-column align-items-center justify-content-center menu_mm">
<i class="fa fa-search menu_mm" aria-hidden="true"></i>
</button>
</form>
</div>
<nav class="menu_nav">

</nav>
</div>
</header>

<section id="intro">

<div class="carousel-item active">
<div class="carousel-background" style="margin-top:150px;"><img src="https://www.business2community.com/wp-content/uploads/2020/12/learning-management-system.jpg" width="1000" height="1100" alt="">
</div>
<div class="carousel-container">
<div class="carousel-content">
<p class="font-color-white">E -LEARNING MANAGEMENT SYSTEM FOR NGO</p>
</div>
</div>
</div>
</section> 
 
<section id="post_job" style="margin:70px 0 0 0;margin-top: 70px;">
<div class="container">
<div class="vertical-space-0"></div>

<div class="job-post-box">
	<div class="row heading"  >
       Login with Student ID Number    </div>
 <div class="row form-group">
	<div class="col-lg ">
		                    <h5 align="center">Login with Student ID Number</h5>
	</div>
	
	
</div> 
<form action="home.php" class="header_search_form menu_mm" method="POST">
<div class="row form-group">
	<div  class="col-lg-4">
		<input type="text" class="form-control" name="id" id="application_no" value="" autocomplete="off" style="float: left;" />
		<label for="exampleInputJobtitle" style="float: right;">Student ID Number<span class="star">&nbsp;*</span></label>
	</div>
	
		
                  	
	
</div>

<div class="row form-group">
	<div  class="col-lg-4">
	<label for="exampleInputJobtitle" style="float: right;">Date of Birth<span class="star">&nbsp;*</span></label>
	</div>
	<div class="">
	<input type="text" name="dob"  />
  </div>
	
</div>

<div class="row" style="background-color: #f1f1f1; height: 60px;" >
	<div class="col-lg-6">
		<input style="float: right; margin-top: 10px;" type="submit" value="Submit" name="submit_contact_form" id="submit_contact_form" class="btn btn-primary">
	</div>

</div>
</form>
<div class="row" style="height: 60px; background-color: white;" >
	<span class="login_div_gap">OR</span>	

</div>                                                           
<div class="row heading"  >
       Login with Mobile     </div>
    <!-- <br> -->
    <div class="row form-group">
	<div class="col-lg ">
		                    <h5 align="center">Login with Mobile Number</h5>
	</div>
	
	
</div> 
<div class="row form-group">
	<div  class="col-lg-4">
		<label for="exampleInputJobtitle" style="float: right;">faculty Id number<span class="star">&nbsp;*</span></label>
	</div>
	<div class="col-lg-4">
		<input type="text" class="form-control" name="application_no" id="application_no" value="" autocomplete="off" style="float: left;" />
                  	</div>
	
</div>
    
<div class="row form-group">
	<div  class="col-lg-4">
		<label for="exampleInputJobtitle" style="float: right;">Mobile Number<span class="star">&nbsp;*</span></label>
	</div>
	<div class="col-lg-4">
		<div class="row">
			<div class="col-lg-3">
				<span style="float: right;">+91</span>
			</div>
			<div class="col-lg-9">
				<input type="text" name="residence_phone" id="residence_phone" autocomplete="off" class="form-control" value="" />
             <br />     			</div>
		</div>
		
	</div>
	
<div class="row" style="background-color: #f1f1f1; height: 60px;" >
	<div class="col-lg-5" style="margin-top: 10px;">
		
	</div>
	<div class="col-lg-6" style="float: center;margin-top: 10px;">
		<input type="submit" value="Submit" name="submit_contact_form" id="submit_contact_form1" class="btn btn-primary">
	</div>
	</div>
</form></div>
</div>
</section>
<footer id="footer" class="background-color-red">
<div class="container-fluid background-color-orange main-footer">
<div class="container text-center">
<div style="padding-top:15px;"><p>© 2022 ---E-learning management system for NGO | Govt. of India</p></div>
</div>
</div>
</footer>
</body>

</html>
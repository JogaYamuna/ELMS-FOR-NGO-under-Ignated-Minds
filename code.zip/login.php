<?php
 $application_no=$_POST['application_no'];
 $dob=$_POST['DOB'];

 //database connection
 $conn=new mysqli('localhost','root','','elms');
 if($conn->connect_error){

 	die('connection failed:'.$conn->connect_error);

 }
 else{
 	$stmt=$conn->prepare("INSERT INTO register(application_no,DOB)VALUES(?,?)");
 	$stmt->binf_param("ss",$application_no,$dob);
 	$stmy-execute();
 	echo'<script>alert("registration successful")</scrit>';
 	$stmt->close();
 	$conn->close();

 }
 ?>
 <?php header('location:home.php');?>


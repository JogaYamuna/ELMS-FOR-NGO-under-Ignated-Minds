<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title></title>
    <style type="text/css">

        @media screen screen and(max-width :500px)
    {
        body{



        }
    }
    .id{
        width: 100%;
        height: 350px ;
        background: lightseagreen;
        padding-top: 10px;
    }
    .lms{
        font-size: 60px;
        text-align: center;
        padding-top: 60px;
        color: white;

    }
        .branch{
            float: left;
            width: 10.33%;
            padding-left: 150px;
            font-size: 25px;
        }
.row::after {
  content: "";
  clear: both;
  display: table;
}
.id1{

    font-size: 30px;
    
}

    </style>

</head>

<body bgcolor="lightsteelblue">

    <div class="id">

        <h1 class="lms">  <img src="https://upparel.com.au/wp-content/uploads/2020/12/lms-product-thumbnail.png" width="100px" height="100px" style="border-radius: 50px; ">Learning Management System</h1>
        <div>
            <p> &nbsp&nbsp&nbsp&nbsp
                A learning management system (LMS) is a software that is designed specifically to create, distribute, and manage the delivery of educational content. The LMS can be hosted as a stand-alone product on the company server, or it can be a cloud-based platform that is hosted by the software firm.Think of a learning management system as technology that can improve learning, make it faster, productive, cost-effective, and what is more important - trackable.

The most basic LMS contains a core functional platform that enables administrators to upload learning content, deliver lessons to students, serving notifications, and share data with authorized users.

An LMS most often operates inside of a web-browser, behind a secure sign-on process. This gives all students and instructors easy access to courses on-the-go, while administrators and leaders can monitor student progress and make improvements.
</p>
        </div>
    </div>
    <div class="id1">
        <h1>Branches</h1>
    </div>

<div class="row">
    <div class="branch">
    <h1><a href="cse.html">CSE</a></h1>
    </div>
    <div class="branch">
        <h1><a href="ece.html">ECE</a></h1>
    </div>
    <div class="branch">
        <h1><a href="mech.html"> MECH </a></h1>
    </div>
    <div class="branch">
        <h1><a href="civil.html">CIVIL</a></h1>
    </div>
    
</div>
<div style="height: 200px;">
    <h3 style="padding-top: 80px; text-align: center;">LMS &copy 2022-2023</h3>
    
</div>



</body>
</html>
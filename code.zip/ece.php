<!DOCTYPE html>
<html>
<head>
<style>
    @media screen screen and(max-width :500px)
    {
        body{


        }
    }
.cse{
    width: 33.33%;
    height: 20%;
}

* {
  box-sizing: border-box;
}

.column {
  float: left;
  width: 33.33%;
  padding-left: 130px;
}

.row::after {
  content: "";
  clear: both;
  display: table;
}
</style>
</head>
<body>


    <div class="cse" >
        <img src="https://th.bing.com/th/id/R.af5bda66a0836fd02fe49f42b09f58eb?rik=Qcz327uvQnKgxQ&riu=http%3a%2f%2faisat.ac.in%2fwp-content%2fuploads%2f2015%2f10%2fElectronics-comm.jpg&ehk=JsFW%2b0tl2QJKBEUtp%2fhnLyFycBdYu3rGP28E817Lypk%3d&risl=&pid=ImgRaw&r=0&sres=1&sresct=1" style=" width: 300% ; height: 350px">
        <h1 style="font-size: 50px; padding-left: 150px;"> Faculty</h1>
        </div> 
    </div>



<div class="row">
  <div class="column">
    <img src="https://cdn1.iconfinder.com/data/icons/avatars-1-5/136/60-512.png" style="width:50%">

                            <h6>T. V. Chaitanya</h6>
                           <p>Asst. Prof(C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 7337242839                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> chaitanyatv@rguktsklm.ac.in                               </li>
                           </ul>

  </div>
  <div class="column">
    <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%">
                                                       <h6>Mr. P. Prasanth Kumar</h6>
                           <p>Asst. Professor (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9492266846                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> prasanthkumar@rguktsklm.ac.in                               </li>
                           </ul>


  </div>
  <div class="column">
    <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%">
                                                       <h6>K Lakshmi Narayana</h6>
                           <p>Asst. Prof(C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 8985274307                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> kalamata0452@rguktsklm.ac.in                               </li>
                           </ul>


  </div>
  <div class="column">
      <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%" >
                                                       <h6>Dr.H.S Vara Prasad,  P.hD</h6>
                           <p>Asst. Professor (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9491321146                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> hsv.prasad@rguktsklm.ac.in                               </li>
                           </ul>

  </div>

    <div class="column">
      <img src="https://cdn1.iconfinder.com/data/icons/avatars-1-5/136/60-512.png" style="width:50%" >
                                                       <h6>Y Lakshmi Prasanna</h6>
                           <p>Asst. Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91                                </li>
                               <li>
                                   <i class="fa fa-envelope"></i> lakshmiprasanna007@rguktsklm.ac.in                               </li>
                           </ul>

  </div>

    <div class="column">
 <img src="https://cdn1.iconfinder.com/data/icons/avatars-1-5/136/60-512.png" style="width:50%">

                                        <h6>B. Teena Ratna Prasuna</h6>
                           <p>Asst. Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 8143723010                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> tina.sfj2005@rguktsklm.ac.in                               </li>
                           </ul>

  </div>

    <div class="column">
      <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%" >

                            <h6>N Ramesh Babu</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 7396704059                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> ramesh.nuthakki@gmail.com                               </li>
                           </ul>
  </div>

    <div class="column">
 <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%">

                                                       <h6>M Ramu</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 6305938893                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> mullangi.ramu0206@gmail.com                               </li>
                           </ul>


  </div>

    <div class="column">
 <img src="https://cdn1.iconfinder.com/data/icons/avatars-1-5/136/60-512.png"style="width:50%">

                                                       <h6>J Chinnari</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 8790664855                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> chinnari.jalla@gmail.com                               </li>
                           </ul>

  </div>

    <div class="column">
      <img src="https://cdn1.iconfinder.com/data/icons/avatars-1-5/136/60-512.png" style="width:50%" >                                              
                                                       <h6>K Sudharani</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 7661959354                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> sudha.ecey7@gmail.com                               </li>
                           </ul>

  </div>
                <div class="column">
                     <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%">
                                                       <h6>B Naga subramanyam</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 8978325318                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> nagasubrahmanyam56@gmail.com                               </li>
                           </ul>
                    
                </div>
                <div class="column">
                     <img src="https://cdn1.iconfinder.com/data/icons/avatars-1-5/136/60-512.png"  style="width:50%">
                                                       <h6>M.V.Tirupatamma</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9491808156                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> anjalipeesa11@gmail.com                               </li>
                           </ul>
                    
                </div>
                <div class="column">
                     <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%">
                                                       <h6>V SasibhushanaRao</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 8985026472                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> sasibhushanarao.varisa@gmail.com                               </li>
                           </ul>
                        </div>
               <div class="column">
                 <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%">
                                                       <h6>T S Gagandeep</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9441736779                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> srinivaas.gagandeep@gmail.com                               </li>
                           </ul>
                </div>

                <div class="column">
                     <img src="https://cdn1.iconfinder.com/data/icons/avatars-1-5/136/60-512.png" style="width:50%">

                                                       <h6>K Jayanthi</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9885915832                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> jayanthik.jayanthik@gmail.com                               </li>
                           </ul>
                </div>
                <div class="column">
                     <img src="https://cdn1.iconfinder.com/data/icons/avatars-1-5/136/60-512.png"style="width:50%">
                                                       <h6>P Tirumala</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 8106273300                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> tirumala.pallerika@gmail.com                               </li>
                           </ul>
                    
                </div>
              <div class="column">
                 <img src="https://cdn1.iconfinder.com/data/icons/avatars-1-5/136/60-512.png" style="width:50%">
                                                       <h6>Bhupathi Bhargavi</h6>
                           <p>Asst. Prof(C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 7032545234                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> bhargavibhoopati@rguktsklm.ac.in                               </li>
                           </ul>
                    
                </div>
                <div class="column">
                     <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png"style="width:50%">
                                                                           <h6>Mr.G.Sivarama Sastry,  M.Tech,(Ph.D)</h6>
                           <p>Asst Prof(C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 8247313739                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> srsastry09@rguktsklm.ac.in                               </li>
                           </ul>
                </div>
                <div class="column">
                     <img src="https://cdn1.iconfinder.com/data/icons/avatars-1-5/136/60-512.png" style="width:50%">
                                                       <h6>Y Ramanamma</h6>
                           <p>Asst. Prof(C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9398267979                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> ramanammay@rgukrsklm.ac.in                               </li>
                           </ul>
                </div>
                <div class="column">
             <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%">

                                                       <h6>B Ganesh</h6>
                           <p>Asst. Prof(C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9704386337                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> ganesh.boga416@rguktsklm.ac.in                               </li>
                           </ul>
                </div>
</div>

</body>
</html>

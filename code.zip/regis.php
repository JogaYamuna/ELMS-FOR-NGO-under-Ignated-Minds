
<!DOCTYPE html>
<html lang="zxx">

<head>
<meta charset="utf-8">
<meta name="author" content="John Doe">
<meta name="description" content="">
<meta name="keywords" content="HTML,CSS,XML,JavaScript">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>E-learning management system for NGO | Govt. of India</title>
<script type="text/javascript" src="https://www.istm.gov.in/files/lms/js/jquery-3.2.1.min.js"></script>
<script src="https://www.istm.gov.in/files/lms/js/4n2NXumNjtg5LPp6VXLlDicTUfA.js"></script><link rel="apple-touch-icon" href="https://www.istm.gov.in/files/lms/images/apple-touch-icon.html">
<link rel="shortcut icon" type="https://www.istm.gov.in//files/lms/image/ico" href="https://www.istm.gov.in//files/lms/images/favicon.html" />

<link rel="stylesheet" href="https://www.istm.gov.in/files/lms/css/bootstrap.min.css">

<link href="https://www.istm.gov.in/files/lms/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

<link href="https://www.istm.gov.in/files/lms/css/matrialize.css" rel="stylesheet">

<link href="https://www.istm.gov.in/files/lms/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

<link rel="stylesheet" href="https://www.istm.gov.in/files/lms/css/style.css">
<link rel="stylesheet" href="https://www.istm.gov.in/files/lms/css/style1.css">
<script>
function check_asops_assessment_logout_time()
{ 
  var url = "https://www.istm.gov.in/lms/update_asops_assessment_logout_time"; 
  // alert(url);
  $.ajax({
			 type: "POST",
			 url: url,
			 data: {'shFCx34Ex297z':'315902e86dfd8b5f26809741df047bb1'},
       success: function(data){         
			 if(data)
			 {
				 alert(data);
				 window.location.replace("https://www.istm.gov.in/lms/home");
			 }   
     });  
}

var interval = setInterval(function () { check_asops_assessment_logout_time(); }, 5000);
</script> 
<meta http-equiv="refresh" content="1000000000000000000000000000000">
</head>
<body>

<header class="header">

<div class="header_container background-color-orange-light" style="margin-top:-10px;">
<div class="container">
<div class="row">
<div class="col">
<div class="header_content d-flex flex-row align-items-center justify-content-start">
<div class="logo_container">
<a href="https://www.istm.gov.in/lms">
<img src="https://lh3.googleusercontent.com/CqE0QcbUTvpMtvUg6RMVO4_sYTLB6GvXenlo9BRBfahWUDX8qyoJvFArdoTVaR7Q-Tdo6r4VDO5F6L4nfSNozswPSYF8kSKOGV3sJs3El6uJ82ZbpASGKtA_f94fiXSbDb4NGItnba2wVomEPdY" width="200" height="105"class="logo-text" alt="">
</a>
</div>
<span style="color:#FFF; margin-left:10px; text-align:center !important;">
<p style="font-size:12px; font-weight:bold; line-height:1.2">WHAT IS LMS</p>
<p style="font-size:18px; font-weight:bold;line-height:1.2">Curious About E-LMS</p>
<p style="font-size:16px; font-weight:bold; line-height:1.2">Surveys and polis social Glamification&</p>
<p style="font-size:16px; font-weight:bold; line-height:1.2">knowledge sharing</p>
</span>
<nav class="main_nav_contaner ml-auto">
<ul class="main_nav">
<li><a href="login1.php" class="btn btn-sm btn-primary signup-link">Login</a></li>
<li><a href="register1.php" class="btn btn-sm btn-primary signup-link">Register</a></li>
</ul>

<div class="hamburger menu_mm menu-vertical">
<i class="large material-icons font-color-white menu_mm menu-vertical">menu</i>
</div>
</nav>
</div>
</div>
</div>
</div>
</div>

<div class="menu d-flex flex-column align-items-end justify-content-start text-right menu_mm trans_400">
<div class="menu_close_container">
<div class="menu_close">
<div></div>
<div></div>
</div>
</div>
<div class="search">
<form action="#" class="header_search_form menu_mm">
<input type="search" class="search_input menu_mm" placeholder="Search" required>
<button class="header_search_button d-flex flex-column align-items-center justify-content-center menu_mm">
<i class="fa fa-search menu_mm" aria-hidden="true"></i>
</button>
</form>
</div>
<nav class="menu_nav">

</nav>
</div>
</header>

<section id="intro">

<div class="carousel-item active">
	<div class="carousel-background" style="margin-top:150px;"><img src="https://thumbs.dreamstime.com/z/lms-learning-management-system-vector-illustration-horizontal-banner-icons-keywords-concept-174035136.jpg" width="1000" height="1100" alt="">
  <div class="carousel-container">
<div class="carousel-content">
<p class="font-color-black">E -LEARNING MANAGEMENT SYSTEM FOR NGO</p>
</div>
</div>
</div>
</div>
</section>


<style type="text/css">
	.ui-datepicker td span, .ui-datepicker td a {
    text-align: center !important;
    }
</style>

<script>
  $(document).ready(function(){
  $('input[type = text]').attr('autocomplete','off');
  $('textarea').attr('autocomplete','off');
  $('.reloadCaptcha').on('click', function(){ //alert("hhh");
          $.get('https://www.istm.gov.in/lms/reload_captcha', function(data){
           // alert(data);
              $('#captchaImg').html(data);
          });
      });
  $('.reloadCaptcha1').on('click', function(){ //alert("hhh");
          $.get('https://www.istm.gov.in/lms/reload_captcha', function(data){
           // alert(data);
              $('#captchaImg1').html(data);
          });
      });
});


  $(function () {
    var start = new Date();
    start.setFullYear(start.getFullYear() - 70);
    var end = new Date();
    end.setFullYear(end.getFullYear() - 20);

    $('#dob').datepicker({
    dateFormat: 'dd-mm-yy',
        changeMonth: true,
        changeYear: true,
        minDate: start,
        maxDate: end,
        yearRange: start.getFullYear() + ':' + end.getFullYear()
    });
});
</script>
<footer id="footer" class="background-color-red">
<div class="container-fluid background-color-orange main-footer">
<div class="container text-center">
<div style="padding-top:15px;"><p>© 2022 ---E-learning management system for NGO | Govt. of India</p></div>
</div>
</div>
</footer>


<script data-cfasync="false" src="https://www.istm.gov.in/files/manpower_portal/js/email-decode.min.js">
</script><script src="https://www.istm.gov.in/files/manpower_portal/js/jquery.min.js"></script>
<script src="https://www.istm.gov.in/files/manpower_portal/js/bootstrap.min.js"></script>
<script src="https://www.istm.gov.in/files/manpower_portal/owlcarousel/owl.carousel.min.js"></script>
<script src="https://www.istm.gov.in/files/manpower_portal/js/jquery-ui.min.js"></script>

<script src="https://www.istm.gov.in/files/manpower_portal/js/custom.js"></script>
<script>
	history.pushState(null, document.title, location.href);
window.addEventListener('popstate', function (event)
{
  history.pushState(null, document.title, location.href);
});
</script>
</body>

</html>
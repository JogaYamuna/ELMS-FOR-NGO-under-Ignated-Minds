<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.ab{
  color: red;
}
.column{
  float: left;
  width: 33.33%;
  padding: 30px;
}
.row::after{
    content: "";
  clear: both;
  display: table;
}

body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
</style>
</head>
<body>


<h3 align="center">Contact Us</h3>
<div class="row">
<div class="column">
  <h6 class="ab">phone </h6>
  <h3>+91 628459320</h3>

  <h6 class="ab">Email </h6>
  <h3>rguktsklm@ac.in</h3>

  <h6 class="ab">Location </h6>
  <h5>RGUKT<i> Nuzvid, krishna district</i> pincode: 521201</h5>
</div>
<div class="column" style="padding-left: 20px;">
  <p>Get in Touch with Us</p>
<div class="container">
  <form action="contact.php" method="POST">
    <label for="fname">First Name</label>
    <input type="text" id="fname" name="firstname" placeholder="Your name..">

    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="lastname" placeholder="Your last name..">

    <label for="country">Country</label>
    <select id="country" name="country">
      <option>India</option>
      <option value="australia">Australia</option>
      <option value="canada">Canada</option>
      <option value="usa">USA</option>
    </select>

    <label for="subject">Subject</label>
    <textarea id="subject" name="subject" placeholder="Write something.." style="height:200px"></textarea>

    <input type="submit" value="Submit" name="submit">
  </form>
</div>
</div>
</div>
</body>
</html>

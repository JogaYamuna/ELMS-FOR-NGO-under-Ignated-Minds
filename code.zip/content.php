<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
  <h1 style="color: white;"><center>Content For the Learning</center></h1>
  <style type="text/css">
    * {
  margin: 0;
  padding: 0;
}

body {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
  background: #161616;
  min-height: 100vh;
}

section::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(#DA22FF, #9733EE);
  clip-path: circle(30% at right 70%);
}

section::after {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(#E55D87, #5FC3E4);
  clip-path: circle(20% at 10% 10%);
}

.container {
  position: relative;
  z-index: 1;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
  margin: 40px 0;
}

.container .card {
  position: relative;
  width: 300px;
  height: 400px;
  background: rgba(255, 255, 255, 0.05);
  margin: 20px;
  box-shadow: 0 15px 35px rgba(0, 0, 0, 0.5);
  border-radius: 15px;
  display: flex;
  justify-content: center;
  align-items: center;
  backdrop-filter: blur(10px);
}

.container .card .content {
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  transition: 0.5s;
}

.container .card:hover .content {
  transform: translateY(-20px);
}

.container .card .content .imgBx {
  position: relative;
  width: 150px;
  height: 150px;
  overflow: hidden;
}

.container .card .content .imgBx img {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.container .card .content .contentBx h3 {
  color: #fff;
  text-transform: uppercase;
  letter-spacing: 2px;
  font-weight: 500;
  font-size: 18px;
  text-align: center;
  margin: 20px 0 10px;
  line-height: 1.1em;
}

.container .card .content .contentBx h3 span {
  font-size: 12px;
  font-weight: 300;
  text-transform: initial;
}

.container .card .sci {
  position: absolute;
  bottom: 50px;
  display: flex;
}

.container .card .sci li {
  list-style: none;
  margin: 0 10px;
  transform: translateY(40px);
  transition: 0.5s;
  opacity: 0;
}

.container .card:hover .sci li {
  transform: translateY(0px);
  opacity: 1;
}

.container .card .sci li a {
  color: #fff;
  font-size: 20px;
}
  </style>
</head>
<body>
  <section>
    <div class="container">
      <div class="card">
        <div class="content">
          <div class="imgBx">
            <img src="https://images-na.ssl-images-amazon.com/images/W/WEBP_402378-T1/images/I/41JLmpw5rbL._SX369_BO1,204,203,200_.jpg">
          </div>
          <div class="contentBx">
             <h3><span>Java Book</span></h3>
          </div>
        </div>
        <ul class="sci">
          <li style="text-align: center;margin-left: 20px;">
           <a href="">Open</a> 
          </li>
        </ul>
      </div>
      <div class="card">
        <div class="content">
          <div class="imgBx">
            <img src="https://images-na.ssl-images-amazon.com/images/I/71IOEdgoCmL.jpg">
          </div>
          <div class="contentBx">
              <h3><span>Python Book</span></h3>
          </div>
        </div>
        <ul class="sci">
          <li style="text-align: center;margin-left: 20px;">
            <a href="">Open</a>
          </li>
        </ul>
      </div>
      <div class="card">
        <div class="content">
          <div class="imgBx">
            <img src="https://images-na.ssl-images-amazon.com/images/I/71sbdF227cL.jpg">
          </div>
          <div class="contentBx">
              <h3><span>DBMS Book</span></h3>
          </div>
        </div>
        <ul class="sci">
          <li style="text-align: center;margin-left: 20px;">
            <a href="">Open</a>
          </li>
        </ul>
      </div>
      <div class="card">
        <div class="content">
          <div class="imgBx">
            <img src="https://images-na.ssl-images-amazon.com/images/I/51mDmYHm31L._SX379_BO1,204,203,200_.jpg">
          </div>
          <div class="contentBx">
              <h3><span>Data Structures</span></h3>
          </div>
        </div>
        <ul class="sci">
          <li style="text-align: center;margin-left: 20px;">
            <a href="">Open</a>
          </li>
        </ul>
      </div>
      <div class="card">
        <div class="content">
          <div class="imgBx">
            <img src="https://freefrontend.com/assets/img/html-css-books/Pro-HTML5-Programming.png">
          </div>
          <div class="contentBx">
              <h3><span>HTML Book</span></h3>
          </div>
        </div>
        <ul class="sci">
          <li style="text-align: center;margin-left: 20px;">
            <a href="">Open</a>
          </li>
        </ul>
      </div>
      <div class="card">
        <div class="content">
          <div class="imgBx">
            <img src="https://images-na.ssl-images-amazon.com/images/I/71j6aLBlXbL.jpg">
          </div>
          <div class="contentBx">
              <h3><span>CSS Book</span></h3>
          </div>
        </div>
        <ul class="sci">
          <li style="text-align: center;margin-left: 20px;">
            <a href="">Open</a>
          </li>
        </ul>
      </div>
      <div class="card">
        <div class="content">
          <div class="imgBx">
            <img src="https://images-na.ssl-images-amazon.com/images/I/515DNyNLIpL._SX404_BO1,204,203,200_.jpg">
          </div>
          <div class="contentBx">
              <h3><span>JavaScript</span></h3>
          </div>
        </div>
        <ul class="sci">
          <li style="text-align: center;margin-left: 20px;">
            <a href="">Open</a>
          </li>
        </ul>
      </div>
      <div class="card">
        <div class="content">
          <div class="imgBx">
            <img src="https://media.wiley.com/product_data/coverImage300/01/04711209/0471120901.jpg">
          </div>
          <div class="contentBx">
              <h3><span>C# & .Net</span></h3>
          </div>
        </div>
        <ul class="sci">
          <li style="text-align: center;margin-left: 20px;">
            <a href="">Open</a>
          </li>
        </ul>
      </div>
      <div class="card">
        <div class="content">
          <div class="imgBx">
            <img src="https://images-na.ssl-images-amazon.com/images/I/512su9kPPtL._SX391_BO1,204,203,200_.jpg">
          </div>
          <div class="contentBx">
              <h3><span>PHP and Mysql</span></h3>
          </div>
        </div>
        <ul class="sci">
          <li style="text-align: center;margin-left: 20px;">
            <a href="">Open</a>
          </li>
        </ul>
      </div>
      <div class="card">
        <div class="content">
          <div class="imgBx">
            <img src="https://images-na.ssl-images-amazon.com/images/I/919En0qA8jL.jpg">
          </div>
          <div class="contentBx">
            <h3><span>C & C++</span></h3>
          </div>
        </div>
        <ul class="sci">
          <li style="text-align:center;margin-left: 20px;">
            <a href="">Open</a>
          </li>
        </ul>
      </div>
    </div>
  </section>
</body>
</html>
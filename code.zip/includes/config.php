<?php
$host="localhost";
$user="root";
$pass="";
$dp="elms";
$con=mysql_connect($host,$user,$pass,$db);
if($con)
{
	echo " ";
}
else
{
	echo "failed to connect";
}
?>
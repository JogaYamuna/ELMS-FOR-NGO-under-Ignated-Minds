<?php 
if($_SERVER['REQUEST_METHOD']=='POST')
{
  include("config.php");
  $fn=$_POST['fn'];
  $ln=$_POST['ln'];
  $gender=$_POST['gender'];
  $dob=$_POST['dob'];
  $age=(int)$_POST['age'];
  $email=$_POST['email'];
  $phone=(int)$_POST['phone'];
  $address=$_POST['address'];
  $year=$_POST['year'];
  $un=$_POST['un'];
  $pass=$_POST['pass'];
  $cpass=$_POST['cpass'];
  $sq=$_POST['sq'];
  $sqa=$_POST['sqa'];
  $ui=$_FILES['ui']['name'];
  echo $sq;
move_uploaded_file($_FILES['ui']['tmp_name'], 'uploads/'.$ui);
 $query="INSERT INTO registeration1 (`fn`,`ln`,`gender`,`dob`,`age`,`email`,`phone`,`address`,`year`,`un`,`pass`,`cpass`,`sq`,`sqa`,`ui`)values('$fn','$ln','$gender','$dob','$age','$email','$phone','$address','$year','$un','$pass','$cpass','$sq','$sqa','$ui')";

 $result=mysqli_query($con,$query);
   // header("Location:regis.php");
    // ('fn','ln','gender','dob','age','email','phone','address','year','un','pass','cpass','sq','sqa','ui')
 if($query)
 {
  echo "Data inserted successfully";
  header("Location:main.php");
 }
 else
 {
  echo "Insert correct Data";
 }
}
 ?>


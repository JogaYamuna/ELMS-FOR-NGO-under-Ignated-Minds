<!DOCTYPE html>
<html>
<head>
<style>
    @media screen screen and(max-width :500px)
    {
        body{


        }
    }
.cse{
    width: 33.33%;
    height: 20%;
}

* {
  box-sizing: border-box;
}

.column {
  float: left;
  width: 33.33%;
  padding-left: 130px;
}

.row::after {
  content: "";
  clear: both;
  display: table;
}
</style>
</head>
<body>


    <div class="cse" >
        <img src="https://clipground.com/images/mechanical-engineering-logo-8.jpg" style=" width: 300% ; height: 300px">
        <h1 style="font-size: 50px; padding-left: 150px;"> Faculty</h1>
        </div>



<div class="row">
  <div class="column">
    <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%">
                                                           <h6>P Chinna Rao </h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9110729092                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> cool.chinna304@gmail.com                               </li>
                           </ul>

  </div>
  <div class="column">
    <img src="https://cdn1.iconfinder.com/data/icons/avatars-1-5/136/60-512.png" style="width:50%">
                                                       <h6>S Kiranmai</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 8985365216                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> s.kiranmai3@gmail.com                               </li>
                           </ul>


  </div>
  <div class="column">
    <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%">
                        <h6>A Srinivas Naik,  M.Tech,(Ph.D)</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 7416261525                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> azmeera91@gmail.com                               </li>
                           </ul>


  </div>
  <div class="column">
      <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%" >
                    <h6>G Raju</h6>
                           <p>Asst prof(c)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9441823084                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> raj.apiiit@gmail.com                               </li>
                           </ul>

  </div>

    <div class="column">
      <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%" >
                                                       <h6>CH Tirumala SuryaPrakash</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 7993095079                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> prakashchintapatla@gmail.com                               </li>
                           </ul>

  </div>

    <div class="column">
 <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%">

                                                       <h6>Mr. K Mohana Krishna Chowdary (Ph.D)</h6>
                           <p>Asst prof</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9703033366                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> mohanakrishna.k@rguktsklm.ac.in                               </li>
                           </ul>

  </div>

  
</div>

</body>
</html>

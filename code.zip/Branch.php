<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Branch</title>
    <style type="text/css">
           @media screen screen and(max-width :500px)
    {
        body{

        }
    }

    .idn{
        padding: 3%;
        background: url(https://wallpaperboat.com/wp-content/uploads/2019/10/cool-website-background-15.jpg);
        background-attachment: fixed;
        background-repeat: no-repeat;
        background-size: 100%;
    }
        .id{
            font-size: 100px;
            text-align: center;
            background: #cccccc ;
            padding: 5%;

        }

        .id2{
            font-size: 30px;
            background-color: cyan;
            padding: 80px;
            margin:100px 120px 10px 120px ;
            border-radius: 80px 20px;

        }
        .id3{
            font-size: 50px;
            text-align: center;
            background: lightblue;
            padding: 2%;
        }
        .id4{
            font-size: 50px;
            float: left;
            padding: 6%;
            margin: 3% ;
            background: cyan;

        }
    </style>
</head>
<body class="idn">
<div class="idm">
    <div class="id1">
        <h1 class="id">E Learning Manangement System</h1>
        
        <p class="id2">  A learning management system (LMS) is a software that is designed specifically to create, distribute, and manage the delivery of educational content. The LMS can be hosted as a stand-alone product on the company server, or it can be a cloud-based platform that is hosted by the software firm.Think of a learning management system as technology that can improve learning, make it faster, productive, cost-effective, and what is more important - trackable.

The most basic LMS contains a core functional platform that enables administrators to upload learning content, deliver lessons to students, serving notifications, and share data with authorized users.

An LMS most often operates inside of a web-browser, behind a secure sign-on process. This gives all students and instructors easy access to courses on-the-go, while administrators and leaders can monitor student progress and make improvements.</p>
    </div>

    <div>
        <h1 class="id3">BRANCH</h1>
    <div >
        <div>
            <h1 class="id4"><a href="cse.php">CSE</a></h1>
        </div>
        <div>
            <h1 class="id4"><a href="ece.php">ECE</a></h1>
        </div>
        <div>
            <h1 class="id4"><a href="mech.php">MECH</a></h1>
        </div>
        <div>
            <h1 class="id4"><a href="civil.php">CIVIL</a></h1>
        </div>
    </div>
    </div>
</div>
</div>
</body>
</html>
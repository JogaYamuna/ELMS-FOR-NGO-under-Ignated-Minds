<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Course</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<h1><center>Courses</center></h1>
	<section class="header"> 
		<nav>
			<div class="nav-links">
				<ul>
					<li><a href="">C_Programming</a></li>
					<li><a href="">Java</a></li>
				</ul>
				<ul>
					<li><a href="">Python</a></li>
					<li><a href="">DBMS</a></li>
				</ul>
				<ul>
					<li><a href="">Web_Technologies</a></li>
					<li><a href="">Data_Structures</a></li>
				</ul>
				<ul>
					<li><a href="">Algorithms</a></li>
					<li><a href="">C_Plus_Plus</a></li>
			</div>
		</nav>
<div class="text-box">
	<h1>Best Course's</h1>
	<p><h3>You can get the best Knowledge from our site.<br>We make you more comfortable with our services</h3></p>
	<a href="">Visit Us To Know More</a> 
</div>	
	</section>
	<div id="python">
	<a href=""><img src="https://i.pinimg.com/736x/8f/23/98/8f2398dcd19c6a1776f6b55c83073c67.jpg" height="300px" width="250px" hspace="50" vspace="50" ></a>
	<a href=""><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQwiKb_Z8YRqBeQe7JZLVNvekj6ngz8WOj3HbBvmuSc7n4haTisEtNp12bX9RQo_W0dnWE&usqp=CAU" height="300px" width="250px" hspace="50" vspace="50"  ></a>
	<a href=""><img src="https://image.shutterstock.com/image-vector/icon-programming-language-vector-c-260nw-506049811.jpg" height="300px" width="250px" hspace="50" vspace="50"  ></a>
	<a href=""><img src="https://qph.cf2.quoracdn.net/main-qimg-317f4ff0db8d0ba328fc6d627af72d89" height="300px" width="250px" hspace="50" vspace="50" ></a>
	<a href=""><img src="https://thumbs.dreamstime.com/b/web-development-vector-icon-symbol-creative-sign-seo-icons-collection-filled-flat-illustration-computer-mobile-logo-155906362.jpg" height="300px" width="250px" hspace="50" vspace="50" ></a>

</body>
</html>

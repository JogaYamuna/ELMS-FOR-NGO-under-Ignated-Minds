<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content=" a new website designed by student of rgukt dept of CSE">
    <meta name="keywords" content=" new website,simple website">
    <meta name ="author" content="Joga.Yamuna">
    <!-- ================-FB  meta -data -===========-->
    <meta property="og:type"  content="website" />
     <meta property="og:title"    content=" Yamuna" />
    <meta property="og:description" content=" student of RGUKT dept of CSE" />
    <!-- ================- twitter meta -data-============-->
    <meta name="twitter:site" content="#" >
    <meta property="og:title" content="vikasivika" />
    <meta property="og:description" content=" stuent of RGUKT dept of cse" />
    <!--=================- link section-============-->
    <link rel="stylesheet" type="text/css" href="register1.css">
    <title>signin page</title>
    <link rel="icon" type="image/png" href="yamu.jpg">
</head>
<body>
  <div class="mainbody">
       <header>
        <hgroup>
          <h1><big>SIGN IN</big></h1>
        </hgroup>
       </header>
       <form action="log.php" class="form-tags" method="POST">
       <div class="row">
        <div class="form-label">
          <label>Email Address:</label>
        </div>
        <div class="form-control">
           <input type="text" required name="email">
          </div>
       </div>
       <div class="row">
        <div class="form-label">
          <label>Password:</label>
        </div>
        <div class="form-control">
           <input type="Password" name="pass">
          </div>
       </div>
       <div class="row">
        <div class="form-control">
           <button type="register" value="Submit" name="submit">Submit</button>
          </div>
       </div>
       <div class="row">
        <div class="form-control">
      <div class="footer"><small><b><q><a href="register.php"><b>Click here to go registeration</b></a></q></b></small></div>
   </div></div>
          <div class="row">
            <div class="form-control">
      <div class="footer"><small><b><q><a href="forget.php"><b>Click here to go to Forgot password  </b></a></q></b></small></div>
   </div></div>
</form>
</body></html>
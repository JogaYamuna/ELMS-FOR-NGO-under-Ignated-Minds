<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title></title>
  <style type="text/css">
  .id 
  {

    font-size: 15px;
    margin: 50px;
    padding: 5px;
    float: left;
  }
  .id1
  {
    width: 100px;
    height: 100px;

  }

    .id2
    {
      text-align: center;
      font-size: 40px;
      margin: 50px;
      background-color: white;
    }






    .id4
    {
      font-size: 20px;
      text-align: center;
      border: 3px solid;
      margin: 5% 5%;
      border-radius: 10px 10px;
      background-color: lightgoldenrodyellow;
      padding: 20px;
    }
    .id5
    {
      font-size: 40px;
      text-align: center;
      padding: 10px;
      background-color: lightcoral;
    }
    .id6{

      background-color: cyan;
    }
        @media screen screen and(max-width :500px)
    {
        body{

        }
    }

  </style>
</head>
<body class="id6">
     <div >
  <div class="id5">
    <h1><u>Internships</u></h1>
  </div>
<div class="id4">
  <h1>list of Courses</h1>
</div>


<div class="idn">
  <div class="id">
    <h1>Data Science</h1>
    <a href="#" ><img src="https://insidebigdata.com/wp-content/uploads/2019/04/DataScience_shutterstock_1054542323.jpg" class="id1"></a>
  </div>
    <div class="id">
    <h1>Machine Learning</h1>
    <a href="#" ><img src="https://wallpapercave.com/wp/wp3205240.jpg" class="id1"></a>
  </div>

      <div class="id">
    <h1>Java</h1>
    <a href="#" ><img src="https://cdn.vox-cdn.com/thumbor/_AobZZDt_RVStktVR7mUZpBkovc=/0x0:640x427/1200x800/filters:focal(0x0:640x427)/cdn.vox-cdn.com/assets/1087137/java_logo_640.jpg" class="id1"></a>
  </div>

      <div class="id">
    <h1>python</h1>
    <a href="#" ><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Python-logo-notext.svg/1200px-Python-logo-notext.svg.png" class="id1"></a>
  </div>

      <div class="id">
    <h1>Artificial Intiligence</h1>
    <a href="#" ><img src="https://elearn.interviewgig.com/wp-content/uploads/2020/04/AI-elearn.png" class="id1"></a>
  </div>

        <div class="id">
    <h1>Cloud Computing</h1>
    <a href="#" ><img src="https://th.bing.com/th/id/OIP.YQNFe1tlIPIo8-K6LcvvAwHaEN?pid=ImgDet&w=734&h=418&rs=1" class="id1"></a>
  </div>


</div>




</body>
</html>
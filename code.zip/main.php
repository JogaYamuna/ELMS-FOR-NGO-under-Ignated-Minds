<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>
		main webpage
	</title>
	<style type="text/css">
	.idn{		
		background-image: url(https://gradients.mijo-design.com/public/uploads/files/lb4.png);
		background-attachment: fixed;
		background-repeat: no-repeat;
		background-size: 100% 100%;
		opacity: 0.5px;


	}
	.id{
		background-color: white;
		border:6px solid red;
		margin: 100px 30px 30px 150px ;
		border-radius:50px 5px;
		padding: 15px;
		float: left;
	}
	.ido{
		border: solid;
	}
	.id1{
		border:3px solid ;
		margin: 80px 50px 30px 50px ;
		border-radius:40px 25px;
		padding: 50px;
		font-size: 22px;
		background-color: white;

	}
	.id2{
		font-size: 60px;
	}
	.id3{
		height: 120px;
		width: 120px;
		padding-left: 30px;
	}

    @media screen screen and(max-width :500px)
    {
        body{

        }
    }

	</style>
</head>
<section>
<body class="idn">
	<div><h1 style="font-size: 100px ; text-align: center;"><u>E Learning Management System </u></h1>
		<div class="id1"><p><b>Learning is the core of delivering any educational or training program by an individual.
Management is the stem of the learning program which manages all the schedules for each and every individual. The system is nothing but an e-platform to deliver the learning programs.

LMS is designed to help an individual to develop, manage and provide online courses and programs to learn. It provides a platform for the students and instructors to learn and highlight their skills wherever and whenever they want as per their convenience.

LMS is an application that is used to administer, track, and report & deliver learning programs.
<p> learning management system is a software application that provides the framework that handles all aspects of the learning process – it’s where you house, deliver, and track your training content. While most often called an LMS, other names that might be used is training management system, learning activity management system or even learning experience platform (LXP). 

A learning content management system (LCMS) sometimes gets confused with an LMS as well. An LCMS is software that is used to author and manage learning content. The two systems are complimentary to one another but not the same. 

An LMS is designed to make life easier for those in charge of training and development—e.g., identifying and assessing individual and organizational learning goals, tracking progress toward meeting those goals and collecting and presenting data for supervising the learning process.  

In addition to delivering content, an LMS can also handle things such as onboarding, compliance and skills gap analysis. </p> </p> </p>
		</div>

		<div class="id5">

			<div class="id">
				<h1 class="id2">Branches </h1>
				<a href="Branch.php" ><img src="https://yt3.ggpht.com/a/AGF-l78LuNxNIBw2OGQ0LSo1a3LRAk4QcaavmsXX4Q=s900-c-k-c0xffffffff-no-rj-mo" class="id3" ></a>
			</div>
			<div class="id">
				<h1 class="id2">Courses </h1>
				<a href="courses.php" cass="id3"><img src="https://th.bing.com/th/id/R.72edbcd644732baeb2a1019cdb806ac9?rik=PNr0Y120j4xNew&riu=http%3a%2f%2fstatic1.squarespace.com%2fstatic%2f557f0ff0e4b013c140af4f7b%2ft%2f56005cbde4b079284e713438%2f1442864318189%2fbook-icon-black.png%3fformat%3d1000w&ehk=wT4V%2f2pVUGiGiHtLAOb8j1FcW2ItQjrqpCZXFcBdTok%3d&risl=&pid=ImgRaw&r=0" class="id3"></a>
			</div >
			<div class="id">
			<h1 class="id2">Webinar</h1>
			<a class="id3" href="Webinar.php"><img src="https://healthyhomestraining.com/wp-content/uploads/2016/12/Webinar-ONLINE-icon.png" class="id3"></a>
			</div>
                             		

			<div class="id">
			<h1 class="id2">Internships</h1>
			<a class="id3"href="Internship.php"><img src="https://bakerromero.com/wp-content/uploads/2019/10/intern.png" class="id3"></a>
			</div>

						<div class="id">
			<h1 class="id2">Certificates</h1>
			<a class="id3" href="Certificate.png"><img src=" https://media.istockphoto.com/vectors/diploma-certificate-award-icon-vector-id670022510?k=6&m=670022510&s=170667a&w=0&h=WbfHWBQHnZnIhuQNgAF0WlEZNKsHEeiuubs-0NedARU= " class="id3"></a>
			</div>

						<div class="id">
			<h1 class="id2">Material</h1>
			<a class="id3" href="material.php"><img src="https://img.freepik.com/free-vector/cartoon-books-pile-school-design_24877-44800.jpg?size=626&ext=jpg" class="id3"></a>
			</div>

                              	

            <div class="id">
			<h1 class="id2">About Us</h1>
			<a class="id3" href="aboutus.php"><img src="https://th.bing.com/th/id/OIP.4Zq-kfUUEHNSyIzub35yvAHaHa?pid=ImgDet&rs=1" class="id3"></a>
			</div>

						<div class="id">
			<h1 class="id2">Contact Us</h1>
			<a class="id3" href="contactus.php"><img src="https://cdn.onlinewebfonts.com/svg/img_297947.png" class="id3"></a>
			</div>
		</div></section>

</body>
</html>
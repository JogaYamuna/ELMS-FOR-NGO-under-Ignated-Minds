<!DOCTYPE html>
<html>
<head>
<style>
    @media screen screen and(max-width :500px)
    {
        body{


        }
    }
.cse{
    width: 10.33%;
    height: 20%;
}

* {
  box-sizing: border-box;
}

.column {
  float: left;
  width: 33.33%;
  padding-left: 130px;
}

.row::after {
  content: "";
  clear: both;
  display: table;
}
</style>
</head>
<body>


    <div class="cse" >
        <img src="https://vimaljangid.files.wordpress.com/2019/01/computer-science-engineering.jpg?w=1024" style=" width: 950% ; height:250px">
        <h1 style="font-size: 50px; padding-left: 150px;"> Faculty</h1>
        </div> 
    </div>



<div class="row">
  <div class="column">
    <img src="https://cdn1.iconfinder.com/data/icons/avatars-1-5/136/60-512.png" style="width:50%">

                                                       <h6>Mrs.S.Lakshmi Sri,  M.Tech</h6>
                           <p>Asst Prof(C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9985157167          0</li>
                               <li>
                                   <i class="fa fa-envelope"></i> lakshmisrisuru@rguktsklm.ac.in                               </li>
                           </ul>

  </div>
  <div class="column">
    <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%">

                                                       <h6>Mr.N.Sesha Kumar,  M.Tech</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9703337730                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> mail2seshu@gmail.com                               </li>
                           </ul>

  </div>
  <div class="column">
    <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%">
                                                           <h6>Mr.K.Dileep Kumar,  M.Tech.,(Ph.D)</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9000254442                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> dileep@rguktsklm.ac.in                               </li>
                           </ul>
  </div>
  <div class="column">
      <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%" >
                            <h6>Mr.K.Vijay Bhaskar,  M.Tech                </h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 7893403432                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> vijaybhaskarcdpc@gmail.com                               </li>
                           </ul>

  </div>

    <div class="column">
      <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%" >
                         <h6>Mr.Ch.Satish kumar, M.Tech,(Ph.D)</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9030224486                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> chilla.satishkumar@gmail.com                               </li>
                           </ul>

  </div>

    <div class="column">
 <img src="https://cdn1.iconfinder.com/data/icons/avatars-1-5/136/60-512.png" style="width:50%">

                                                             <h6>Ms.M.Roopa, M.Tech</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 8125114136                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> roopa1237@gmail.com                               </li>
                           </ul>

  </div>

    <div class="column">
      <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%" >
                             <h6>Mr.T.Anil Kumar,  M.Tech</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9703843263                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> anilkumar10491@gmail.com                               </li>
                           </ul>

  </div>

    <div class="column">
 <img src="https://cdn1.iconfinder.com/data/icons/avatars-1-5/136/60-512.png" style="width:50%">

                            <h6>Ms.J.Vishnu Priyanka,  M.Tech</h6>
                           <p>Asst Prof(C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 7013299187                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> vishnupriya.javvadi@rguktsklm.ac.in                               </li>
                           </ul>

  </div>

    <div class="column">
 <img src="https://cdn1.iconfinder.com/data/icons/avatars-1-5/136/60-512.png"style="width:50%">

                                                             <h6>Mrs.M.Mounika Rayudu,  M.Tech</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 7093678968                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> mounikamaddamsetti@gmail.com                               </li>
                           </ul>

  </div>

    <div class="column">
      <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%" >                                              
                          <h6>Mr.M.Rithvik,  M.Tech,(Ph.D)</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9502170822                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> madugularithvik20@rguktsklm.ac.in                               </li>
                           </ul>

  </div>
                <div class="column">
                     <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%">
                        <h6>Mr.K.Ramana,  M.Tech</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9989320235                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> ramanakancharapu@gmail.com                               </li>
                           </ul>
                    
                </div>
                <div class="column">
                     <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png"  style="width:50%">
                            <h6>Mr.T.Narasimhaappadu,  M.Tech</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9492638410                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> narasimhaurce@gmail.com                               </li>
                           </ul>
                    
                </div>
                <div class="column">
                     <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%">
                            <h6>Mr.T.Narasimhaappadu,  M.Tech</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9492638410                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> narasimhaurce@gmail.com                               </li>
                           </ul>
                        </div>
               <div class="column">
                 <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%">
                        <h6>Mr.Y.Ramesh,  M.Tech</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 7306509500                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> Ramesh.yajjala42@gmail.com                                </li>
                           </ul>
                </div>

                <div class="column">
                     <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%">
                     <h6>Mr.Y.Kumar Shekar,  M.Tech</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9573336902                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> sekhar.yet@gmail.com                               </li>
                           </ul>
                </div>
                <div class="column">
                     <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" alt="Forest" style="width:50%">
                                                                           <h6>Mr.S.Chandra Sekhar,  M.Tech</h6>
                           <p>Asst Prof</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 7702025677                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> chandrasekhar.s@rguktsklm.ac.in                               </li>
                           </ul>
                    
                </div>
              <div class="column">
                 <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%">
                                                                       <h6>Dr.D.Rajesh,  M.Tech.,Ph.D</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9966720920                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> rajesh.duvvuru@rguktsklm.ac.in                               </li>
                           </ul>
                    
                </div>
                <div class="column">
                     <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png"style="width:50%">
                                                                           <h6>Mr.G.Sivarama Sastry,  M.Tech,(Ph.D)</h6>
                           <p>Asst Prof(C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 8247313739                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> srsastry09@rguktsklm.ac.in                               </li>
                           </ul>
                </div>
                <div class="column">
                     <img src="https://cdn1.iconfinder.com/data/icons/avatars-1-5/136/60-512.png" style="width:50%">

                        <h6>Mrs.Ch.Lakshmi Bala,  M.Tech,(Ph.D)</h6>
                           <p>Asst Prof(C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 6281711851                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> lakshmibala@rguktsklm.ac.in                               </li>
                           </ul>
                </div>
                <div class="column">
             <img src="https://cdn1.iconfinder.com/data/icons/avatars-1-5/136/60-512.png" style="width:50%">

                          <h6>Mrs.V.Pavani,  M.Tech</h6>
                           <p>Asst Prof(C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 6303551212                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> pavanivambra@rguktsklm.ac.in                               </li>
                           </ul>
                </div>
</div>

</body>
</html>

<!DOCTYPE html>
<html>
<head>
<style>
    @media screen screen and(max-width :500px)
    {
        body{


        }
    }
.cse{
    width: 33.33%;
    height: 20%;
}

* {
  box-sizing: border-box;
}

.column {
  float: left;
  width: 33.33%;
  padding-left: 130px;
}

.row::after {
  content: "";
  clear: both;
  display: table;
}
</style>
</head>
<body>


    <div class="cse" >
        <img src="https://cipranchi.ac.in/images/placemnt/civil.png" style=" width: 250% ; height: 200px">
        <h1 style="font-size: 50px; padding-left: 150px;"> Faculty</h1>
        </div> 
    </div>



<div class="row">
  <div class="column">
    <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%">

                                                       <h6>Ch.Teja Kiran</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9441595877                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> tej2teju@gmail.com                                </li>
                           </ul>

  </div>
  <div class="column">
    <img src="https://cdn3.iconfinder.com/data/icons/avatars-round-flat/33/man5-512.png" style="width:50%">
                                                       <h6>N R N Prem Kumar</h6>
                           <p>Asst Prof (C)</p>
                           <ul class="mx-0 pl-2 pr-0">
                               <li>
                                   <i class="fa fa-phone"></i> +91 9951558848                               </li>
                               <li>
                                   <i class="fa fa-envelope"></i> premnakkana@gmail.com                               </li>
                           </ul>


  </div>
 
</div>

</body>
</html>
